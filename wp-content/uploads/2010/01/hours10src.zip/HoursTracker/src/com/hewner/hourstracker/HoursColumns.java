/*
	Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/


package com.hewner.hourstracker;

import android.net.Uri;
import android.provider.BaseColumns;

public class HoursColumns implements BaseColumns {

	// do not instantiate
	private HoursColumns() {}
	
	public static final String AUTHORITY = "com.hewner.provider.HoursTracker";
	
    /**
     * The content:// style URL for this table
     */
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/hours");

    /**
     * The MIME type of {@link #CONTENT_URI} providing a directory of notes.
     */
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.hewner.hours";

    /**
     * The MIME type of a {@link #CONTENT_URI} sub-directory of a single note.
     */
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.hewner.hoursitem";

    
    /**
     * The title of the note
     * <P>Type: TEXT</P>
     */
    public static final String NAME = "name";
    
    /**
     * The timestamp for when the note was created
     * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
     */
    public static final String CREATED_DATE = "created";
    
    /**
     * The timestamp for when the timer was last started for this item
     * Should only be filled in for one hoursitem at most
     * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
     */
    public static final String TIMER_DATE = "timer";
    
    /**
     * The number of hours till this goal is reached
     * 
     * <P>Type: INTEGER </P>
     */
    public static final String GOAL_HOURS = "goal";
    
    /**
     * The timestamp for when the note was created
     * <P>Type: FLOAT (long from System.curentTimeMillis())</P>
     */
    public static final String HOURS = "hours";

    /**
     * The default sort order for this table
     */
    public static final String DEFAULT_SORT_ORDER = _ID;
    
}
