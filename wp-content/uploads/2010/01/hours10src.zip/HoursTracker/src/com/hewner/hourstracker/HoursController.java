/*
    Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.hewner.hourstracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class HoursController extends Activity {
	
	private static final String TAG = "HoursController";
	private HoursView view;
	private Cursor hoursCursor;
	private long currentHoursItem;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		Log.i(TAG, "Starting onCreate.");
		
	    super.onCreate(savedInstanceState);
	    
	    
		hoursCursor = getContentResolver().query(HoursColumns.CONTENT_URI, null, null, null, null);
		startManagingCursor(hoursCursor);
		
		hoursCursor.moveToFirst(); 
		int latestIndex = 0;
		long latestTime = -1;
		long latestId = -1;
		while(!hoursCursor.isAfterLast())
		{
			HoursItem item = new HoursItem(hoursCursor);
			if(item.timerStart() > latestTime)
			{
				latestTime = item.timerStart();
				latestIndex = hoursCursor.getPosition();
				latestId = item.id();
			}
			hoursCursor.moveToNext();	
		}
		
		view = new HoursView(this);
	    view.initializeUI(hoursCursor, latestIndex);
	    currentHoursItem = latestId;
	    registerTimerUpdates();
	    if(hoursCursor.getCount() == 0) {
			view.enterNoSkillState();
		}
	}
	
	private static final int MENU_NEW_SKILL = 1;
	private static final int MENU_ADD_HOURS = 2;
	private static final int MENU_DELETE = 3;
	public boolean onCreateOptionsMenu(Menu menu) {
	    menu.add(0, MENU_NEW_SKILL, 0, getString(R.string.add_activity_name));
	    menu.add(0, MENU_ADD_HOURS, 0, getString(R.string.add_hours));
	    menu.add(0, MENU_DELETE, 0, getString(R.string.delete_item));
	    return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	    case MENU_NEW_SKILL:
	        addHoursItem();
	        return true;
	    case MENU_ADD_HOURS:
	        addHours();
	        return true;
	    case MENU_DELETE:
	        delete();
	        return true;
	    }
	    return false;
	}
	
	private void delete() {
		showDialog(DELETE_CONFIRM_DIALOG);		
	}


	private void addHours() {
		showDialog(HOURS_ENTRY_DIALOG);
	}

	static final int HOURS_ENTRY_DIALOG = 1;
	static final int DELETE_CONFIRM_DIALOG = 2;
	
	protected Dialog onCreateDialog(int id) {
	    final HoursController parent = this;
	    AlertDialog.Builder builder;
	    AlertDialog alert;
	    switch(id) {
	    case HOURS_ENTRY_DIALOG:
	    	ViewGroup inflatedView = (ViewGroup) View.inflate(this, R.layout.gethoursdialog, null);
	    	final EditText textbox = (EditText) inflatedView.getChildAt(0);
	    	builder = new AlertDialog.Builder(this);
	    	builder.setMessage(getString(R.string.add_hours_prompt))
	    	       .setCancelable(true)
	    	       .setView(inflatedView)
	    	       .setPositiveButton(getString(R.string.add_text), new DialogInterface.OnClickListener() {
	    	           public void onClick(DialogInterface dialog, int id) {
	    	               addHours(Float.parseFloat(textbox.getText().toString()));
	    	           }
	    	       })
	    	       .setNegativeButton(getString(R.string.cancel_text), new DialogInterface.OnClickListener() {
	    	           public void onClick(DialogInterface dialog, int id) {
	    	                dialog.cancel();
	    	           }
	    	       });
	    	alert = builder.create();
	        break;
	    case DELETE_CONFIRM_DIALOG:
	        builder = new AlertDialog.Builder(this);
	        builder.setMessage(getString(R.string.delete_item_prompt))
	               .setCancelable(true)
	               .setPositiveButton(getString(R.string.delete_text), new DialogInterface.OnClickListener() {
	                   public void onClick(DialogInterface dialog, int id) {
	           				getContentResolver().unregisterContentObserver(observer);
	           				observer = null;
	                	   itemForId(currentHoursItem).delete(getContentResolver());
	                	   hoursCursor.requery();
	                	   if(hoursCursor.getCount() == 0) {
	                		   view.enterNoSkillState();
	                	   }
	                   }
	               })
	               .setNegativeButton(getString(R.string.cancel_text), new DialogInterface.OnClickListener() {
	                   public void onClick(DialogInterface dialog, int id) {
	                        dialog.cancel();
	                   }
	               });
	        alert = builder.create();
	        break;
	    default:
	        alert = null;
	    }
	    return alert;
	}

	public void onReset() {
		HoursItem item = itemForId(currentHoursItem);
		item.startTimer(getContentResolver());
	}
	
	
	private HoursItem itemForId(long id)
	{
		Uri itemUri = Uri.withAppendedPath(HoursColumns.CONTENT_URI, Long.toString(id));
		Cursor itemCursor = getContentResolver().query(itemUri, null, null, null, null);
		if(itemCursor.getCount() != 1) {
			throw new RuntimeException("Unexpected number of results when querying id " + id);
		}
		itemCursor.moveToFirst();
		HoursItem item = new HoursItem(itemCursor);
		itemCursor.close();
		return item;
	}
	
	private class HoursItemContentObserver extends ContentObserver
	{
		private long id;
		public HoursItemContentObserver(Handler handler, long id)
		{
			super(handler);
			this.id = id;
		}
		
		public void onChange(boolean selfChange) {
			HoursItem item = itemForId(id);
			view.updateDetailedDescription(item);			
		}
	}
	
	private ContentObserver observer;
	private void changeCurrentItem(long id)
	{
		
		if(observer != null) {
			getContentResolver().unregisterContentObserver(observer);
		}
		observer = new HoursItemContentObserver(new Handler(),id);
		getContentResolver().registerContentObserver(
				Uri.withAppendedPath(HoursColumns.CONTENT_URI, Long.toString(id)), 
				false,
				observer
				
		);
		HoursItem item = itemForId(id);
		if(id != currentHoursItem)
		{
			item.startTimer(getContentResolver());
		}
		view.updateDetailedDescription(item);
		currentHoursItem = id;
		
	}
	
	public void onHoursItemSelected(long id) {
		changeCurrentItem(id);
	}
	 
	public void addHoursItem()
	{
		Uri foo = HoursColumns.CONTENT_URI;
		startActivity(new Intent(Intent.ACTION_INSERT, foo));
	}
	

	public void registerTimerUpdates()
	{
		Runnable updater = new Runnable() {
			public void run() {
				try {
					view.updateTimer(itemForId(currentHoursItem));
					HoursItem item = itemForId(currentHoursItem);
					view.updateDetailedDescription(item);
				} catch (RuntimeException e)
				{
					//just wait
				}
				registerTimerUpdates();				
			}
		};
		view.postDelayed(updater, 1000);
	}
	
	public void commitTimer()
	{
		HoursItem item = itemForId(currentHoursItem);
		item.setHours(getContentResolver(), item.hoursSinceTimer() + item.hours());
		item.startTimer(getContentResolver());
		view.updateTimer(item);
	}
	
	public void addHours(float hours)
	{
		HoursItem item = itemForId(currentHoursItem);
		item.setHours(getContentResolver(), hours + item.hours());
	}
}
