/*
    Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.hewner.hourstracker;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
 
public class HoursAddController extends Activity {

	private static final String TAG = "HoursAddController";
	
	public void onCreate(Bundle savedInstanceState) {
		
	    super.onCreate(savedInstanceState);
	    
		setContentView(R.layout.add);
		
	    OnClickListener exitListener = new OnClickListener() {
	        public void onClick(View v) {
	        	finish();
	        }
	    };
	    Button button = (Button) findViewById(R.id.AddCancelButton);
	    button.setOnClickListener(exitListener);
	    
	    final Activity activity = this;
	    
	    OnClickListener addListener = new OnClickListener() {
	        public void onClick(View v) {
	        	
	        	TextView editBox = (TextView) activity.findViewById(R.id.AddName);
	        	TextView goalBox = (TextView) activity.findViewById(R.id.GoalHoursEditText);
	        	HoursItem.createHoursItem(getContentResolver(),
	        			editBox.getText().toString(), 
	        			Long.parseLong(goalBox.getText().toString()));	        	
	        	finish();
	        }
	    };
	    button = (Button) findViewById(R.id.AddButton);
	    button.setOnClickListener(addListener);
	    

	}

}
