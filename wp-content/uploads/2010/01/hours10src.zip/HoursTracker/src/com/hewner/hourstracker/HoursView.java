/*
    Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/


package com.hewner.hourstracker;

import java.util.Random;

import com.hewner.hourstracker.R;


import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class HoursView {
	
	private static final String TAG = "HoursView"; 
	private HoursController controller;
	
	public HoursView(HoursController controller)
	{
		this.controller = controller;
	}
	
	public void initializeUI(Cursor hoursCursor, int startPosition)
	{
		controller.setContentView(R.layout.main);
		
	    OnClickListener resetListener = new OnClickListener() {
	        public void onClick(View v) {
	        	controller.onReset();
	        }
	    };
	    Button resetButton = (Button) controller.findViewById(R.id.resetButton);
	    // Register the onClick listener with the implementation above
	    
	    resetButton.setOnClickListener(resetListener);

	    Spinner s = (Spinner) controller.findViewById(R.id.spinner);
	    
	    s.setAdapter(makeHoursAdapter(hoursCursor));
	    if(hoursCursor.getCount() > 0) {
	    	s.setSelection(startPosition);
	    }
	    OnItemSelectedListener mMessageClickedHandler = new OnItemSelectedListener() {

	    	@Override
	    	public void onItemSelected(AdapterView<?> parent, View v, int position, long id)
	        {
	            controller.onHoursItemSelected(id);
	        }


			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// do nothing
			}
	    };
	    s.setOnItemSelectedListener(mMessageClickedHandler);
	    
	    ViewGroup bigButton = (ViewGroup) controller.findViewById(R.id.BigButtonLayout);
	    BigButtonListener listener = new BigButtonListener();
	    bigButton.setOnClickListener(listener);
	    ImageButton bigButtonTimer = (ImageButton) controller.findViewById(R.id.TimerBigButton);
	    bigButtonTimer.setOnClickListener(listener);
	}
	
	private class BigButtonListener implements OnClickListener
	{
		public void onClick(View arg0) {
			Log.i(TAG, "CLICK");
			controller.commitTimer();
		}
    	
    }
	
	public void enterNoSkillState() {
		updateDetailedDescription("No skills exist.  Add one using the menu.");
	    ViewGroup bigButton = (ViewGroup) controller.findViewById(R.id.BigButtonLayout);
	    bigButton.setVisibility(View.INVISIBLE);
	    Button resetButton = (Button) controller.findViewById(R.id.resetButton);
	    resetButton.setVisibility(View.INVISIBLE);

	}
	
	public void updateDetailedDescription(HoursItem item) {
	    updateDetailedDescription(longDescription(item));
	}
	
	public void updateDetailedDescription(String description) {
	    TextView field = (TextView) controller.findViewById(R.id.DetailedDescription);
	    field.setText(description);
	}
	
	private float roundTo(float number, int places) {
		double scale = Math.pow(10, places);
		return (float) ((float) Math.round(scale * number)/scale);
	}
	
	public String longDescription(HoursItem item) {
		
		double hoursLeft = (item.goalHours() - item.hours())/item.getPercentTime();
		long yearsLeft = (long) hoursLeft / (365 * 24);
		float monthsLeft = (float) (hoursLeft - 365*24*yearsLeft)/(30*24);
		String timeLeftEstimate;
		
		if(yearsLeft < 1000) { 
			timeLeftEstimate =
				yearsLeft + " years " + roundTo(monthsLeft, 1) + " months to " +
				item.goalHours() + " hours";
		} else {
			timeLeftEstimate = "More than 1000 years";
		}
		return "Hours logged: " + roundTo(item.hours(),1) + 
			"\nPercent of time: " + roundTo(item.getPercentTime()*100,2) +
			"\nRate: " + roundTo(item.getPercentTime()*24*7,1) + " hours per week." +
			"\n" + timeLeftEstimate;
		
	}
	
	public void updateTimer(HoursItem item)
	{
		ViewGroup bigButton = (ViewGroup) controller.findViewById(R.id.BigButtonLayout);
		bigButton.setVisibility(View.VISIBLE);
		Button resetButton = (Button) controller.findViewById(R.id.resetButton);
	    resetButton.setVisibility(View.VISIBLE);

		TextView timerStartField = (TextView) controller.findViewById(R.id.BigButtonDate);
		timerStartField.setText(item.timerStartDateText());
		TextView hoursField = (TextView) controller.findViewById(R.id.BigButtonHours);
		hoursField.setText(roundTo(item.hoursSinceTimer(),2) + " hours");
	}
	
	public void postDelayed(Runnable action, long milliseconds)
	{
		ViewGroup button = (ViewGroup) controller.findViewById(R.id.BigButtonLayout);
		button.postDelayed(action, milliseconds);
	}
	
	private class HoursItemBinder implements SimpleCursorAdapter.ViewBinder
	{
		public boolean setViewValue(View view, Cursor c, int columnIndex) {
			HoursItem item = new HoursItem(c);
			String description = item.name() + " " + roundTo(item.hours(),2) + " (" + roundTo(item.getPercentTime() * 100,1) + "%)";
			((TextView) view).setText(description);
			return true;
		}		
	}
	
	public SimpleCursorAdapter makeHoursAdapter(Cursor hoursCursor)
	{
    	SimpleCursorAdapter adapter = new SimpleCursorAdapter(controller,
    			android.R.layout.simple_spinner_item,
    			hoursCursor,
    			new String[] { HoursColumns.NAME },
    			new int[] {android.R.id.text1 });
    	adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    adapter.setViewBinder(new HoursItemBinder());
	    return adapter;   		
	}
}