/*
    Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/


package com.hewner.hourstracker;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

public class HoursItem {

	protected String name;
	protected float hours;
	protected long startDate;
	protected long timerStartDate;
	protected long id;
	protected int goalHours;
	
	public HoursItem(Cursor c) {
		name = c.getString(c.getColumnIndexOrThrow(HoursColumns.NAME));
		hours = c.getFloat(c.getColumnIndexOrThrow(HoursColumns.HOURS));
		startDate = c.getLong(c.getColumnIndexOrThrow(HoursColumns.CREATED_DATE));
		timerStartDate = c.getLong(c.getColumnIndexOrThrow(HoursColumns.TIMER_DATE));
		goalHours = c.getInt(c.getColumnIndexOrThrow(HoursColumns.GOAL_HOURS));
		id = c.getLong(c.getColumnIndexOrThrow(HoursColumns._ID));
	}
	
	public float getPercentTime() {
		long timeElapsed = System.currentTimeMillis() - startDate;
		float timeSpent = 60 * 60 * 1000 * hours;
		return timeSpent/timeElapsed;
	}
	
	public float hours() {
		return hours;
	}
	
	public long goalHours() {
		return goalHours;
	}
	
	public String name() {
		return name;
	}
	
	public void startTimer(ContentResolver resolver)
	{
		ContentValues values = new ContentValues();
		values.put(HoursColumns.TIMER_DATE, System.currentTimeMillis());
		Uri itemUri = Uri.withAppendedPath(HoursColumns.CONTENT_URI, Long.toString(id));
		int count = resolver.update(itemUri, values, null, null);
		if (count != 1)
			throw new RuntimeException("Unexpected result on setHours");
		
	}
	
	public void setHours(ContentResolver resolver, float hours)
	{
		ContentValues values = new ContentValues();
		values.put(HoursColumns.HOURS, hours);
		Uri itemUri = Uri.withAppendedPath(HoursColumns.CONTENT_URI, Long.toString(id));
		int count = resolver.update(itemUri, values, null, null);
		if (count != 1)
			throw new RuntimeException("Unexpected result on setHours");
	}
	
	static Uri createHoursItem(ContentResolver resolver, String name, long goalHours)
	{
		ContentValues values = new ContentValues();
		values.put(HoursColumns.NAME, name);
		values.put(HoursColumns.GOAL_HOURS, goalHours);
		return resolver.insert(HoursColumns.CONTENT_URI, values);
		
	}
	
	public String timerStartDateText()
	{
		Date date = new Date(timerStartDate);
		SimpleDateFormat formatter = new SimpleDateFormat("MMM d h:mm a");
		
		return formatter.format(date);
	}
	
	public float hoursSinceTimer()
	{
		float difference = System.currentTimeMillis() - timerStartDate;
		return (float) (difference / (1000.0 * 60 * 60));
	}
	
	public long id()
	{
		return id;
	}
	
	public long timerStart()
	{
		return timerStartDate;
	}
	
	public void delete(ContentResolver resolver)
	{
		Uri itemUri = Uri.withAppendedPath(HoursColumns.CONTENT_URI, Long.toString(id));
		int count = resolver.delete(itemUri, null, null);
		if (count != 1)
			throw new RuntimeException("Unexpected result on delete");
	
	}
}
