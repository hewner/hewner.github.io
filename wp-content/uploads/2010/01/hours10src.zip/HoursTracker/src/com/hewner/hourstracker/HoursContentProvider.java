/*
    Copyright (C) 2010  Michael Hewner
    This file is part of 10K Hours.

    10K Hours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    10K Hours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with 10K Hours.  If not, see <http://www.gnu.org/licenses/>.
*/


package com.hewner.hourstracker;

import java.util.HashMap;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.provider.SyncStateContract.Columns;
import android.text.TextUtils;
import android.util.Log;

public class HoursContentProvider extends ContentProvider {

	//for logging
	private static final String TAG = "HoursContentProvider";
	
	private static final String DATABASE_NAME = "hours.db";
	private static final int DATABASE_VERSION = 6;
	private static final String HOURS_TABLE_NAME = "hours";	
	
    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null,  DATABASE_VERSION);
        } 
    	
		@Override
		public void onCreate(SQLiteDatabase db) {
            Log.w(TAG, "Creating table " + HOURS_TABLE_NAME);
            db.execSQL("CREATE TABLE " + HOURS_TABLE_NAME + " ("
                    + HoursColumns._ID + " INTEGER PRIMARY KEY,"
                    + HoursColumns.NAME + " TEXT,"
                    + HoursColumns.CREATED_DATE + " INTEGER,"
                    + HoursColumns.TIMER_DATE + " INTEGER,"
                    + HoursColumns.GOAL_HOURS + " INTEGER,"
                    + HoursColumns.HOURS + " REAL"
                    + ");");		
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + HOURS_TABLE_NAME);
            onCreate(db);
			
		}

    }
    
    private DatabaseHelper mOpenHelper;

    @Override
    public boolean onCreate() {
        mOpenHelper = new DatabaseHelper(getContext());
        return true;
    }
    
	@Override
	public int delete(Uri uri, String where, String[] whereArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count;
        switch (sUriMatcher.match(uri)) {
        case HOURS:
            count = db.delete(HOURS_TABLE_NAME, where, whereArgs);
            break;

        case HOURS_ID:
            String hourId = uri.getPathSegments().get(1);
            count = db.delete(HOURS_TABLE_NAME, HoursColumns._ID + "=" + hourId
                    + (!TextUtils.isEmpty(where) ? " AND (" + where + ')' : ""), whereArgs);
            break;

        default:
            throw new IllegalArgumentException("Unknown URI " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);
        return count;
	}

	private static final UriMatcher sUriMatcher;
	private static final int HOURS = 1;
	private static final int HOURS_ID = 2;

	static {
		sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        sUriMatcher.addURI(HoursColumns.AUTHORITY, "hours", HOURS);
        sUriMatcher.addURI(HoursColumns.AUTHORITY, "hours/#", HOURS_ID);
	}
	
	@Override	
	public String getType(Uri uri) {
        switch (sUriMatcher.match(uri)) {
        case HOURS:
            return HoursColumns.CONTENT_TYPE;

        case HOURS_ID:
            return HoursColumns.CONTENT_ITEM_TYPE;

        default:
            throw new IllegalArgumentException("Unknown URI " + uri);
        }
	}

	@Override
	public Uri insert(Uri uri, ContentValues initialValues) {
        // Validate the requested uri
        if (sUriMatcher.match(uri) != HOURS) {
            throw new IllegalArgumentException("Unknown URI " + uri);
        }
        
        if (initialValues == null) {
        	throw new IllegalArgumentException("Null values");
        }
        
        Long now = Long.valueOf(System.currentTimeMillis());

        // Make sure that the fields are all set
        if (initialValues.containsKey(HoursColumns.CREATED_DATE) == false) {
            initialValues.put(HoursColumns.CREATED_DATE, now);
        }

        if (initialValues.containsKey(HoursColumns.TIMER_DATE) == false) {
            initialValues.put(HoursColumns.TIMER_DATE, now);
        }
        
        if(initialValues.containsKey(HoursColumns.NAME) == false) {
        	throw new IllegalArgumentException("No name specified");        	
        }
        
        if (initialValues.containsKey(HoursColumns.HOURS) == false) {
            initialValues.put(HoursColumns.HOURS, 0.0);
        }
        
        if (initialValues.containsKey(HoursColumns.GOAL_HOURS) == false) {
            initialValues.put(HoursColumns.GOAL_HOURS, 10000);
        }
        
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        long rowId = db.insertOrThrow(HOURS_TABLE_NAME, HoursColumns.HOURS, initialValues);

        Uri noteUri = ContentUris.withAppendedId(HoursColumns.CONTENT_URI, rowId);
        getContext().getContentResolver().notifyChange(noteUri, null);
        Log.i(TAG, "Successfully added record " + rowId);
        return noteUri;
	}
	
	private static HashMap<String, String> sHoursProjectionMap;
	static {
		
        sHoursProjectionMap = new HashMap<String, String>();
        sHoursProjectionMap.put(HoursColumns._ID, HoursColumns._ID);
        sHoursProjectionMap.put(HoursColumns.NAME, HoursColumns.NAME);
        sHoursProjectionMap.put(HoursColumns.CREATED_DATE, HoursColumns.CREATED_DATE);
        sHoursProjectionMap.put(HoursColumns.HOURS, HoursColumns.HOURS);
        sHoursProjectionMap.put(HoursColumns.TIMER_DATE, HoursColumns.TIMER_DATE);
        sHoursProjectionMap.put(HoursColumns.GOAL_HOURS, HoursColumns.GOAL_HOURS);
        
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
			String sortOrder) {
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

		switch (sUriMatcher.match(uri)) {
		case HOURS:
			qb.setTables(HOURS_TABLE_NAME);
			qb.setProjectionMap(sHoursProjectionMap);
			break;

	    case HOURS_ID:
	            qb.setTables(HOURS_TABLE_NAME);
	            qb.setProjectionMap(sHoursProjectionMap);
	            qb.appendWhere(HoursColumns._ID + "=" + uri.getPathSegments().get(1));
	            break;

	    default:
	    	throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
        // If no sort order is specified use the default
        String orderBy;
        if (TextUtils.isEmpty(sortOrder)) {
            orderBy = HoursColumns.DEFAULT_SORT_ORDER;
        } else {
            orderBy = sortOrder;
        }
		
        // Get the database and run the query
        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);

        // Tell the cursor what uri to watch, so it knows when its source data changes
        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String where, String[] whereArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count;
        switch (sUriMatcher.match(uri)) {
        case HOURS:
            count = db.update(HOURS_TABLE_NAME, values, where, whereArgs);
            break;

        case HOURS_ID:
            String noteId = uri.getPathSegments().get(1);
            count = db.update(HOURS_TABLE_NAME, values, HoursColumns._ID + "=" + noteId
                    + (!TextUtils.isEmpty(where) ? " AND (" + where + ')' : ""), whereArgs);
            break;

        default:
            throw new IllegalArgumentException("Unknown URI " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);
        return count;
	}
	
}
