/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//predicts max temperature on one day based on previous 16 days
package Networks;

import Fundamentals.*;
import java.io.*;

/**
 *
 * @author Gil Goldshlager
 */
public class Temperature {

    
    static double[][] temperatures;

    public static void main(String[] args) throws IOException {
        File f = FileManipulator.createFile("TempData");
        double[][] temp = FileManipulator.getData(f, 1);
        for(int i = 0; i < temp.length; i++){
            temp[i][0] = (temp[i][0] - 30) / 100;
        }
        double[][] INPUT = new double[temp.length - 17][16];
        double[][] OUTPUT= new double[temp.length - 17][1];
        for (int i = 0; i < temp.length - 17; i++) {
            for (int j = i; j < i + 16; j++) {
                INPUT[i][j - i] = temp[j][0];
            }
            OUTPUT[i][0] = temp[i + 16][0];
        }
        Data trainingData = new Data(INPUT, OUTPUT);
        Network network = new Network();
        network.setStructure(new int[]{16, 350, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
        //network.printWeights();
        double val = .0005, workableVal = .0005;
        double acceptableErr = 2;
        BackPropagation trainer = new BackPropagation(network, trainingData, 175, val, acceptableErr);
trainer.printData();
        double[][] info = trainer.findBestLimiter(workableVal, .0002, .0008,30);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch/5;
        for (int i = 3; i < info.length-3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i+j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);

        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, .02);

        for (int i = 0;
                i < result.length;
                i++) {
            System.out.print(result[i] + " ");
        }
    
    }
}
