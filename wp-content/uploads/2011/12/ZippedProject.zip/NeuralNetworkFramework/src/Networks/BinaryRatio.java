/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;
import Fundamentals.*;
/**
 *
 * @author Gil Goldshlager
 */
public class BinaryRatio {

    static Data trainingData;

    public static void main(String[] args) {
        int numData = 200;
        double[][] input = new double[numData][16];
        double[][] output = new double[numData][1];
        for (int i = 0; i < numData; i++) {
            input[i] = Data.getRandomBinary(16);
            output[i][0] = getOnesRatio(input[i]);
           // System.out.println(trainingData[1][i][0]);
        }
        trainingData = new Data(input, output);
        
        Network network = new Network();
        network.setStructure(new int[]{16, 500, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
        //network.printWeights();

        int minEpoch;
        double val = .003;
        double workableVal = .001;
        double acceptableErr = 3;
        //try with 250 if this fails
        int maxTrain = 150;
        BackPropagation trainer = new BackPropagation(network, trainingData, maxTrain, val, acceptableErr);
        trainer.printData();
        trainer.setLimiter(0.004412 );
        trainer.trainNetwork();
       // double[] info = trainer.findBestLimiter(workableVal, .0001, .005, 50);
        //double bestVal = info[0];
        //minEpoch = (int) info[1];
        double maxDiff = .2;
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, maxDiff);
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + " ");
        }
    }

    public static double getOnesRatio(double[] input) {
        boolean[] TF = new boolean[input.length];
        for (int i = 0; i < input.length; i++) {
            if (Math.abs(1 - input[i]) < .03125) {
                TF[i] = true;
            } else {
                TF[i] = false;
            }
        }
        return getOnesRatio(TF);

    }

    public static double getOnesRatio(boolean[] input) {
        int numOnes = 0;
        for(int i = 0; i < input.length; i++){
            if(input[i]){
                numOnes++;
            }
        }
        return (double)numOnes/input.length;
    }
}

