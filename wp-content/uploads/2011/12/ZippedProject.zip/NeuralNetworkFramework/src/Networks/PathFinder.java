/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;
import Fundamentals.*;
import java.io.*;
/**
 *
 * @author Gil Goldshlager
 */
public class PathFinder {
    static double[][] INPUT = new double[][]{
        {0,1,1,1,
         0,1,0,1,
        1,0,1,1,
        1,1,0,0},
        {0,0,1,1,
         0,1,0,1,
        1,0,0,1,
        1,1,0,0},
        {1,1,0,1,
         0,1,0,1,
        1,0,0,1,
        0,1,0,0},
        {0,1,0,1,
         0,1,0,1,
        1,1,1,1,
        1,0,0,0},
        {0,0,0,0,
         0,0,0,0,
        0,0,0,0,
        0,0,0,0},
        {0,1,1,1,
         1,1,0,1,
        1,0,0,0,
        0,1,0,0},
        {0,0,1,1,
         0,1,0,0,
        1,1,1,0,
        1,1,0,0},
        {0,1,0,1,
         1,0,1,0,
        0,1,1,0,
        0,0,1,0},
        {1,1,0,1,
         1,1,0,0,
        1,0,0,0,
        0,1,0,0},
        {1,1,1,0,
         0,0,0,1,
        1,0,0,1,
        1,0,0,0},
        {0,1,1,1,
         0,0,0,1,
        1,1,1,0,
        1,1,1,0},
        {0,1,1,1,
         0,0,0,1,
        1,0,1,0,
        1,1,0,0},
        {0,0,1,1,
         0,0,0,0,
        1,0,1,1,
        1,1,0,1},
        {0,1,0,1,
         1,0,1,0,
        0,1,1,0,
        1,1,1,0},
        {1,1,0,1,
         0,1,0,1,
        1,0,1,0,
        1,0,0,0},
        {0,0,1,1,
         0,1,0,1,
        1,0,1,0,
        0,1,0,1},
        {0,1,1,1,
         0,0,0,1,
        1,0,0,1,
        1,1,0,0},
        {0,0,0,1,
         0,1,0,1,
        1,0,1,1,
        1,1,0,0},
        {1,1,1,1,
         0,0,0,1,
        1,0,0,1,
        1,1,1,0},
        {1,1,1,0,
         0,1,0,0,
        0,0,1,0,
        0,1,0,1},
        {0,1,0,1,
         0,1,0,1,
        1,0,0,1,
        0,1,0,0},
        {0,1,0,1,
         1,0,1,1,
        1,0,0,0,
        0,0,1,0},
        {1,0,0,1,
         1,1,0,1,
        1,1,0,1,
        1,1,0,1},
        {0,1,0,1,
         0,1,1,1,
        1,0,1,0,
        1,1,1,0},
        {0,1,1,1,
         1,0,0,1,
        1,0,0,1,
        1,0,1,0},
        {0,1,0,1,
         0,0,0,1,
        1,1,1,1,
        1,1,0,1},
        {0,1,1,1,
         0,1,0,1,
        1,1,1,1,
        0,0,0,0},
        {1,1,0,0,
         0,1,1,1,
        0,0,0,1,
        0,0,1,0},
        {0,0,1,1,
         0,1,1,0,
        1,1,1,1,
        1,1,0,0},
        {0,1,1,1,
         0,1,0,1,
        1,1,1,1,
        1,1,0,0},
        {0,0,0,1,
         0,1,0,0,
        1,0,1,0,
        1,1,0,0}
        };
    
    static double[][] OUTPUT = new double[][]{
        {0},
        {0},
        {1},
        {1},
        {0},
        {1},
        {0},
        {0},
        {1},
        {1},
        {0},
        {0},
        {1},
        {0},
        {1},
        {1},
        {0},
        {0},
        {0},
        {1},
        {0},
        {0},
        {1},
        {1},
        {0},
        {1},
        {1},
        {1},
        {1},
        {1},
        {0} 
    };
    
    
    public static void main(String[] args){
        Data trainingData = new Data(INPUT, OUTPUT);
          Network network = new Network();
        network.setStructure(new int[]{16, 50, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
        //network.printWeights();
        double val = .0005, workableVal = .05;
        double acceptableErr = .01;
        BackPropagation trainer = new BackPropagation(network,trainingData, 25, val, acceptableErr);
trainer.printData();
        double[][] info = trainer.findBestLimiter(workableVal, .0005, .05,100);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch/5;
        for (int i = 3; i < info.length-3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i+j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
        System.out.println(minEpoch);
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, .02);

        for (int i = 0;
                i < result.length;
                i++) {
            System.out.print(result[i] + " ");
        }
    
    }
}
