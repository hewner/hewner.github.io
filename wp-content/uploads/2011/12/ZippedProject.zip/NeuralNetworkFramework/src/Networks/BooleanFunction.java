/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;

import Fundamentals.*;
import java.io.*;

/**
 *
 * @author Gil Goldshlager
 */
public class BooleanFunction {

    static Data trainingData;

    public static void main(String[] args) throws IOException {
        int numData = 200;
        double[][] input = new double[numData][16];
        double[][] output = new double[numData][1];
        for (int i = 0; i < numData; i++) {
            input[i] = Data.getRandomBinary(16);
            boolean[] TF = getValue(input[i]);
            while (TF.length >= 2) {
                TF = condense(TF);
            }
            if (TF[0]) {
                output[i][0] = .8;
            } else {
                output[i][0] = .2;
            }
        }
        trainingData = new Data(input, output);

        FileManipulator.dataToFile("BooleanData", trainingData.getInputData(), trainingData.getOutputData());

        Network network = new Network();
        network.setStructure(new int[]{16, 500, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
        //  network.printWeights();

        double val = .03;
        double workableVal = .001;
        double acceptableErr = 2;
        //try with 250 if this fails
        int maxTrain = 150;
        BackPropagation trainer = new BackPropagation(network, trainingData, maxTrain, val, acceptableErr);
        trainer.printData();
        double[][] info = trainer.findBestLimiter(workableVal, .0005, .004, 30);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch / 5;
        for (int i = 3; i < info.length - 3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i + j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
        double maxDiff = .2;
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, maxDiff);

        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + " ");
        }
    }

    public static boolean[] getValue(double[] binaryList) {
        boolean[] value = new boolean[binaryList.length];
        for (int i = 0; i < binaryList.length; i++) {
            if (binaryList[i] == 0) {
                value[i] = false;
            } else {
                value[i] = true;
            }
        }
        return value;

    }

    public static boolean[] condense(boolean[] before) {
        if (before.length % 2 == 1) {
            boolean[] temp = new boolean[before.length + 1];
            System.arraycopy(before, 0, temp, 0, before.length);
            temp[temp.length - 1] = false;
            before = temp;
        }
        boolean[] after = new boolean[(int) (before.length / 2)];
        for (int i = 0; i < after.length; i++) {
            if (i % 2 == 1) {
                if (before[2 * i] || before[2 * i + 1]) {
                    after[i] = true;
                } else {
                    after[i] = false;
                }
            } else {
                if (before[2 * i] && before[2 * i + 1]) {
                    after[i] = true;
                } else {
                    after[i] = false;
                }
            }
        }
        return after;
    }
}
