/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;

import Fundamentals.*;

/**
 *
 * @author Gil Goldshlager
 */
public class TextClassifier {

    static final double[][] INPUT = new double[][]{
        {0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1},
        {1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1},
        {0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0},
        {1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1},
        {1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1},
        {1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0},
        {0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0},
        {0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0},
        {0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1},
        {0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1},
        {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0},
        {0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1},
        {0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0},
        {0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1},
        {1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
        {0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1},
        {1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1},
        {1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1},
        {0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
        {1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0},
        {1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {},
        {}};
    static final double[][] IDEAL = new double[][]{
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.8},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2},
        {.2}};

    public static void main(String[] args) {
        for (int i = 16; i < 63; i++) {
            INPUT[i] = Data.getRandomBinary(16);
            for (int j = 0; j < INPUT[i].length; j++) {
                   // System.out.print(INPUT[i][j] + " ");
            }
          //  System.out.println();
        }
        IMAGE.shuffle(INPUT, IDEAL);
        Network network = new Network();
        network.setStructure(new int[]{16,400,1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
       // network.printWeights();
        
        double val = .0005;
         double  acceptableErr = .1;
         BackPropagation trainer = new BackPropagation(network, new Data(INPUT,IDEAL),55,val,acceptableErr);
        trainer.printData();
        double[][] info = trainer.findBestLimiter(.0005, .0001, .005, 40);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch/5;
        for (int i = 3; i < info.length-3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i+j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
       
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length-1,.4);

        for (int i = 0;
                i < result.length;
                i++) {
            System.out.print(result[i] + " ");
        }
    }


   
}
