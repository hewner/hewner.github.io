/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;

import Fundamentals.*;
import java.io.*;

/**
 *
 * @author Gil Goldshlager
 */
public class CountryClassification {

    public static void main(String[] args) throws IOException {
        //YOU WILL NEED TO CHANGE THE DIRECTORY TO FIT YOUR COMPUTER
        double[][] INPUT = FileManipulator.getDataArray(new File("c:\\Users\\Gil Goldshlager\\My Documents\\Neural net data\\finalData"), 2);
        double[][] OUTPUT = FileManipulator.getData(new File("c:\\Users\\Gil Goldshlager\\My Documents\\Neural net data\\finalData"), 1);
        Data trainingData = new Data(INPUT, OUTPUT);
        trainingData.scaleInputColumns(0, 1);

        for (int i = 0; i < INPUT.length; i++) {
            for (int j = 0; j < INPUT[i].length; j++) {
                System.out.print(trainingData.getInputEntry(i, j) + "-");
            }
            System.out.println();
        }
        Network network = new Network();
        network.setStructure(new int[]{12, 500, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();
        network.printWeights();

        double val = .003;
        double workableVal = .0003;
        double acceptableErr = 2;
        //try with 250 if this fails
        int maxTrain = 90;
        BackPropagation trainer = new BackPropagation(network, trainingData, maxTrain, val, acceptableErr);

        double[][] info = trainer.findBestLimiter(workableVal, .0001, .001, 40);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch / 5;
        for (int i = 3; i < info.length - 3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i + j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
        double maxDiff = .2;
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, maxDiff);

        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + " ");
        }
    }

    public static void getResults(Network network, double[][] INPUT, double[][] OUTPUT, int startPos, boolean[] result) {
        for (int i = 0; i < result.length; i++) {
            network.compute(INPUT[i + startPos]);
            double[] calculated = network.getOutput();
            double[] ideal = OUTPUT[i + startPos];
            result[i] = true;
            Loop:
            for (int j = 0; j < ideal.length; j++) {
                if (Math.abs(calculated[j] - ideal[j]) > .2) {
                    result[i] = false;
                }
            }
        }
    }
}
