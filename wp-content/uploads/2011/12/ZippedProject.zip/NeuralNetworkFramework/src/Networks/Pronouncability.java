/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Networks;

import Fundamentals.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author Gil Goldshlager
 */
//Takes in encoded 3 character syllables and outputs a 1 if the syllable is pronouncable and a 0 if it isn't
public class Pronouncability {

    public static void main(String[] args) throws IOException {
        //YOU WILLN NEED TO GO TO THE FileManipulator CLASS AND CHANGE THE DIRECTORY FOR IT TO FIND THE FILE
        File f = Fundamentals.FileManipulator.createFile("Strings");
        /*CREATES RANDOM STRINGS: need to use this once, then evaluate the pronouncability of each generated string.  After that you can reuse the file.  
         * PrintWriter out = new PrintWriter(new FileWriter(f));
        String[] inputs = new String[500];
        int num[] = new int[3];
        for(int i = 0; i < 500; i++){
        for(int c = 0; c < 3; c++){
        num[c] = (int)(Math.random()*26);
        }
        inputs[i] = toString(num);
        }
        for(int i = 0; i < inputs.length; i++){
        System.out.println(inputs[i]);
        out.println(inputs[i]);
        }
        out.close();
         */
        BufferedReader in = new BufferedReader(new FileReader(f));
        StringTokenizer st;
        double[][] INPUT = new double[500][16];
        double[][] OUTPUT = new double[500][1];
        for (int i = 0; i < 500; i++) {
            st = new StringTokenizer(in.readLine());
            INPUT[i] = getDoubleArray(st.nextToken());
            OUTPUT[i][0] = Integer.parseInt(st.nextToken());
            if (OUTPUT[i][0] == 0) {
                OUTPUT[i][0] = .2;
            }
            if (OUTPUT[i][0] == 1) {
                OUTPUT[i][0] = .8;
           }
          //  System.out.println(i);
        }

        Data trainingData = new Data(INPUT, OUTPUT);
        Network network = new Network();
        network.setStructure(new int[]{16, 500, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();

        double val = .003;
        double workableVal = .001;
        double acceptableErr = 2;
        //try with 250 if this fails
        int maxTrain = 50;
        BackPropagation trainer = new BackPropagation(network,trainingData, maxTrain, val, acceptableErr);
        trainer.printData();
        double[][] info = trainer.findBestLimiter(workableVal, .0001, .004, 40);
        double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch/5;
        for (int i = 3; i < info.length-3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i+j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
        System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
        double maxDiff = .2;
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, maxDiff);

        for (int i = 0;
                i < result.length;
                i++) {
            System.out.print(result[i] + " ");
        }
    }

    private static double[] getDoubleArray(String st) {
        double[] result = new double[16];
        for (int i = 0; i < 3; i++) {
            int val = getValue(st.charAt(i));
            System.out.print(val + " ");
            double[] portion = toBitArray(val);
            System.arraycopy(portion, 0, result, 5 * i, 5);
        }
        System.out.println();
        result[15] = 0;
        return result;
    }

    private static double[] toBitArray(int k) {
        double[] result = new double[5];
        for (int p = 4; p > -1; p--) {
            if (k > Math.pow(2, p)) {
                k -= Math.pow(2, p);
                result[4 - p] = 1;
            }
        }
        return result;
    }

    private static String toString(int[] n) {
        String result = "";
        for (int i = 0; i < n.length; i++) {
            result = result.concat(String.valueOf(toChar(n[i])));
        }
        return result;
    }

    private static int getValue(char a) {
        return (Character.getNumericValue(a) - 10);
    }

    private static char toChar(int n) {
        switch (n) {
            case 0:
                return 'a';
            case 1:
                return 'b';
            case 2:
                return 'c';
            case 3:
                return 'd';
            case 4:
                return 'e';
            case 5:
                return 'f';
            case 6:
                return 'g';
            case 7:
                return 'h';
            case 8:
                return 'i';
            case 9:
                return 'j';
            case 10:
                return 'k';
            case 11:
                return 'l';
            case 12:
                return 'm';
            case 13:
                return 'n';
            case 14:
                return 'o';
            case 15:
                return 'p';
            case 16:
                return 'q';
            case 17:
                return 'r';
            case 18:
                return 's';
            case 19:
                return 't';
            case 20:
                return 'u';
            case 21:
                return 'v';
            case 22:
                return 'w';
            case 23:
                return 'x';
            case 24:
                return 'y';
            case 25:
                return 'z';
            default:
                return 'A';
        }
    }
}
