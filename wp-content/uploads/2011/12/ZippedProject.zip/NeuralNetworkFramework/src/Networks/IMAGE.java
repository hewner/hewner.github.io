package Networks;

import Fundamentals.*;
import java.io.*;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gil Goldshlager
 */
public class IMAGE {

    public final static File f = new File("Neural Network Data");
    public static double INPUT[][] = {
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 0,
            0, 1, 0, 1},
        {1, 1, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 0, 0, 0},
        {0, 0, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 0, 1, 1,
            1, 1, 1, 0,
            0, 0, 0, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 0, 1, 1},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            1, 0, 1, 0},
        {0, 1, 0, 0,
            1, 0, 1, 1,
            1, 1, 1, 0,
            0, 0, 1, 0},
        {0, 0, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 0, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 0, 1, 1,
            1, 1, 0, 0,
            0, 0, 1, 0},
        {1, 1, 0, 0,
            0, 1, 1, 1,
            1, 0, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 1, 1, 0},
        {0, 1, 0, 1,
            0, 1, 1, 1,
            1, 1, 1, 0,
            1, 0, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 1, 1, 0,
            0, 1, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            1, 0, 1, 0,
            0, 0, 1, 0},
        {0, 1, 0, 0,
            0, 1, 1, 1,
            0, 1, 1, 0,
            0, 0, 1, 0},
        {1, 0, 1, 0,
            0, 1, 1, 1,
            1, 0, 1, 0,
            0, 1, 0, 1},
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 0,
            1, 1, 0, 1},
        {1, 0, 1, 0,
            0, 0, 0, 1,
            1, 0, 0, 0,
            0, 1, 0, 1},
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 0,
            0, 1, 0, 0},
        {1, 0, 1, 0,
            0, 0, 0, 1,
            1, 0, 1, 0,
            0, 1, 0, 1},
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 0, 0,
            0, 1, 0, 1},
        {1, 0, 1, 0,
            0, 0, 0, 1,
            1, 0, 1, 0,
            0, 1, 0, 1},
        {1, 1, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 1,
            0, 1, 0, 1},
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 0,
            1, 1, 0, 1},
        {1, 0, 1, 1,
            0, 1, 0, 1,
            1, 0, 1, 0,
            0, 0, 0, 1},
        {1, 0, 1, 0,
            1, 1, 0, 0,
            1, 0, 1, 0,
            0, 0, 0, 1},
        {1, 0, 1, 0,
            0, 1, 0, 1,
            1, 0, 1, 0,
            1, 1, 0, 1},
        {1, 0, 1, 0,
            0, 1, 1, 1,
            1, 0, 1, 0,
            0, 1, 0, 0},
        {1, 0, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 0, 1},
        {1, 1, 1, 1,
            1, 0, 0, 1,
            1, 1, 1, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 1, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 0, 0,
            0, 0, 0, 1,
            1, 1, 1, 1},
        {1, 0, 1, 1,
            1, 0, 0, 1,
            1, 0, 1, 1,
            1, 1, 1, 1},
        {1, 0, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {0, 1, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            0, 1, 1, 1},
        {1, 0, 1, 1,
            1, 0, 0, 1,
            1, 0, 0, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 0, 0,
            1, 0, 0, 1,
            0, 1, 1, 1},
        {1, 1, 1, 1,
            1, 0, 0, 1,
            1, 1, 0, 1,
            1, 1, 1, 1},
        {1, 1, 1, 1,
            1, 1, 0, 1,
            1, 0, 1, 1,
            1, 1, 1, 1}};
    public static double XOR_INPUT_EXPANDED[][] = {
        {-1},
        {0},
        {1}};
//These are all of the possible inputs to the IMAGE operator. Likewise, the expected outputs are also stored as an array.
    //Collapse | Copy Code
    public static double IDEAL[][] = {
        {-1},
        {0},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {-1},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0},
        {0}};
    public static double XOR_IDEAL_EXPANDED[][] = {
        {.275},
        {.3160},
        {.472},
        {.5},
        {.549},
        {.356},
        {.091},
        {.133}};

    public static void main(String[] args) throws IOException {
        shuffle(INPUT, IDEAL);

        Network network = new Network();
        network.setStructure(new int[]{16, 30, 1}, new Function[]{new LinearFunction(), new SigmoidalFunction(), new LinearFunction()});
        network.randomizeWeights();

        double val = .0005;
        double acceptableErr = .1;
        int maxTrain = 36;
        BackPropagation trainer = new BackPropagation(network, new Data(INPUT, IDEAL), maxTrain, val, acceptableErr);
        trainer.printData();
        //change to .01, 30
        trainer.trainNetwork();
        /*double minEpoch = info[0][1] + info[1][1] + info[2][1] + info[3][1] + info[4][1];
        int bestVal = 2;
        minEpoch = minEpoch/5;
        for (int i = 3; i < info.length-3; i++) {
            double thisEpoch = 0;
            for (int j = -2; j < 3; j++) {
                thisEpoch += info[i+j][1];
            }
            thisEpoch = thisEpoch / 5;
            System.out.println("Average " + info[i][0] + " Epochs " + thisEpoch);
            if (thisEpoch < minEpoch) {
                minEpoch = thisEpoch;
                bestVal = i;
            }
        }
         * */
       // System.out.println("Best val: " + bestVal + ", Epoch: " + minEpoch);
        double maxDiff = .2;
        boolean[] result = trainer.getResults(trainer.getMaxTrain(), trainer.getTrainingOutput().length - 1, maxDiff);

        for (int i = 0;
               i < result.length;
               i++) {
            System.out.print(result[i] + " ");
        }


    }

    public static void shuffle(double[][] list1, double[][] list2) {
        for (int pos = 0; pos < list1.length; pos++) {
            int n = (int) (Math.random() * (list1.length - pos)) + pos;
            double[] temp = list1[n];
            list1[n] = list1[pos];
            list1[pos] = temp;
            temp = list2[n];
            list2[n] = list2[pos];
            list2[pos] = temp;
        }
    }
}
