package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gil Goldshlager
 */
public class LinearFunction implements Function {

    double proportion;
    double offset;

    public LinearFunction(double c) {
        proportion = c;
        offset = 0;
    }

    public LinearFunction(double c, double o) {
        proportion = c;
        offset = o;
    }

    public LinearFunction() {
        proportion = 1;
        offset = 0;
    }

    public double f(double x) {
        return proportion * x + offset;
    }

    public double dydx(double x) {
        return proportion;
    }
}
