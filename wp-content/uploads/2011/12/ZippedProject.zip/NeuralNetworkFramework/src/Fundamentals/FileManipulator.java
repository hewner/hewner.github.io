/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

import java.io.*;
import java.util.*;

/**
 *
 * @author Gil Goldshlager
 */
public class FileManipulator {
    //file directly- must change this to work on your computer!
    static  String directory = "c:\\Users\\Gil Goldshlager\\My Documents\\Neural net data\\";
    
    //creates a new file with the given file name
    public static File createFile(String fName) throws IOException {
        File f = new File(directory + fName);
        if (!f.exists()) {
            f.createNewFile();
        }
        return f;

    }
    
    
    
    //Filters the data in one file to match what is contained in another file-
    //Template: file to be matched
    //In: file to match to the template
    //Out: output file which contains the data from the file "in," but only the data about countries which are
    //also describe in the file "template"
    public static void match(File template, File in, File o) throws IOException {
        int l = getLines(in);
        Scanner scanner;
        BufferedReader r = new BufferedReader(new FileReader(in));
        String currCountry;
        o.createNewFile();
        PrintWriter out = new PrintWriter(new FileWriter(o));
        for (int i = 0; i < l; i++) {
            String str = r.readLine();
            scanner = new Scanner(str);
            currCountry = scanner.next();
            while (!scanner.hasNextDouble()) {
                currCountry = currCountry.concat(scanner.next());
            }
            if (contains(template, currCountry)) {
                out.println(str);
            }
        }
        out.close();
    }


    //creates a file with all of the data from a given input and output array: output is printed first on each line, then input
    public static void dataToFile(String name, double[][] INPUT, double[][] IDEAL) throws IOException {

        File o = createFile(name);
        FileWriter out = new FileWriter(o);
        for (int i = 0; i < INPUT.length; i++) {
            String toPrint = IDEAL[i][0] + " ";
            //System.out.println(toPrint);
            for (int j = 0; j < INPUT[0].length; j++) {
                toPrint = toPrint.concat(INPUT[i][j] + " ");
                //System.out.println(toPrint);
            }
            out.write(toPrint + " " + System.getProperty("line.separator"));
        }
        out.close();
    }

    //prints an entire file
    public static void printFile(String name) throws IOException {
        File f = createFile(name);
        FileReader in = new FileReader(f);
        System.out.print("File text:");
        char currLine;
        while (in.ready()) {
            currLine = (char) in.read();
            System.out.print(currLine);
        }
        in.close();
    }

    //used for getting data from a file from the CIA world factbook
    public static void getRelevantDataFromCIA(String fileInName, String fileOutName) throws IOException {
        File f = new File("c:\\Users\\Gil Goldshlager\\My Documents\\Neural net data\\" + fileInName);
        Scanner in = new Scanner(new BufferedReader(new FileReader(f)));
        String[] names;
        double[] data;
        int lines = getLines(f);
        int pos = 0;
        names = new String[lines];
        data = new double[lines];
        while (in.hasNext()) {
            System.out.println(in.next());
            names[pos] = in.next();
            while (!in.hasNextDouble()) {
                String nextToken = in.next();
                if (!nextToken.equals("$")) {
                    names[pos] = names[pos].concat(" " + nextToken);
                }
            }
            data[pos] = in.nextDouble();
            pos++;
        }
        File o = new File("c:\\Users\\Gil Goldshlager\\My Documents\\Neural net data\\" + fileOutName);
        if (!o.exists()) {
            o.createNewFile();
        }
        PrintWriter out = new PrintWriter(new FileWriter(o));
        for (int i = 0; i < data.length; i++) {
            out.println(names[i] + " " + data[i]);
        }
        out.close();
        in.close();
    }

    //returns the number of columns of double values in a file
    public static int getNumDataTypes(File f) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        Scanner s = new Scanner(r.readLine());
        while (!s.hasNextDouble()) {
            s.next();
        }
        int num = 0;
        while (s.hasNextDouble()) {
            s.next();
            num++;
        }
        return num;

    }

    //Takes in files with data about the same set of objects, and merges the data
    //The first column must be the name of the object that the data is about, with following columns containing data about the object
    //This method outputs a file associating all of the appropriate data in the files with each object
    //The output file will contain only the objects which are described by every file
    public static void mergeData(File[] files, File output) throws IOException {
        PrintWriter out = new PrintWriter(new FileWriter(output));
        File f = files[0];
        String[] refNames = new String[getLines(f)];
        double[] currData;
        int numTypes = getNumDataTypes(f);
        double[][] refData = new double[getLines(f)][numTypes];
        BufferedReader r = new BufferedReader(new FileReader(f));
        Scanner scanner = new Scanner(r);
        for (int i = 0; i < getLines(f); i++) {
            refNames[i] = scanner.next();
            while (!scanner.hasNextDouble()) {
                refNames[i] = refNames[i].concat(scanner.next());
            }
            for (int c = 0; c < numTypes; c++) {
                refData[i][c] = scanner.nextDouble();
            }

        }
        for (int i = 0; i < refNames.length; i++) {
            System.out.print("Checking if all data have information for " + refNames[i] + "- ");
            if (allContainCountry(files, 1, files.length - 1, refNames[i])) {
                System.out.println("Success");
                out.print(refNames[i]);
                for (int d = 0; d < refData[i].length; d++) {
                    out.print("   " + refData[i][d]);
                }
                for (int num = 1; num < files.length; num++) {
                    currData = getData(files[num], refNames[i]);
                    for (int d = 0; d < currData.length; d++) {
                        out.print("   " + currData[d]);
                    }

                }
                out.println();
            } else {
                System.out.println("Failure");
            }
        }
        out.close();
    }

    //Gets data from a file
    //In each line, this method skips forward to a specific column and gets all data after that column
    //Column skipped to is determined by the parameter position
    public static double[][] getData(File f, int position) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        String currLine;
        int pos = 0;
        double[][] result = new double[getLines(f)][1];
        Loop:
        while (r.ready()) {
            currLine = r.readLine();
            Scanner scanner = new Scanner(currLine);
            while (!scanner.hasNextDouble()) {
                scanner.next();
            }
            for (int i = 1; i < position; i++) {
                scanner.next();
            }
            result[pos][0] = scanner.nextDouble();
            pos++;

        }
        return result;

    }

    //for country classification specifically- gets a specific data point of a specific country
    public static double getData(File f, String country, int position) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        String currLine;
        StringTokenizer st = new StringTokenizer("0");
        Loop:
        while (r.ready()) {
            currLine = r.readLine();
            st = new StringTokenizer(currLine);
            while (st.hasMoreTokens()) {
                if (st.nextToken().equals(country)) {
                    for (int i = 1; i < position; i++) {
                        st.nextToken();
                    }
                    break Loop;
                }
            }
        }
        return Double.parseDouble(st.nextToken());
    }

    //for country classification specifically- gets data associated with specific country
    public static double[] getData(File f, String country) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        String currLine;
        int numData = getNumDataTypes(f);
        double[] result = new double[numData];
        StringTokenizer st = new StringTokenizer("0");
        Loop:
        while (r.ready()) {
            currLine = r.readLine();
            st = new StringTokenizer(currLine);
            if (st.nextToken().equals(country)) {
                for (int i = 0; i < numData; i++) {
                    result[i] = Double.parseDouble(st.nextToken());
                }
                break Loop;
            }
        }
        return result;
    }

    //for country classification specifically- used to ensure that the countries used have data for all attributes
    public static boolean allContainCountry(File[] files, int startFile, int endFile, String country) throws IOException {
        for (int num = startFile; num <= endFile; num++) {
            if (!contains(files[num], country)) {
                return false;
            }
        }
        return true;
    }

    //tests whether a file contain a certain string (surrounded by spaces)
    public static boolean contains(File f, String str) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        String currLine;
        StringTokenizer st;
        while (r.ready()) {

            currLine = r.readLine();
            st = new StringTokenizer(currLine);
            while (st.hasMoreTokens()) {
                if (st.nextToken().equals(str)) {
                    return true;
                }
            }
        }
        return false;
    }

    //returns number of lines in a file
    public static int getLines(File f) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        int lines = 0;
        while (r.ready()) {
            r.readLine();
            lines++;
        }
        r.close();
        return lines;
    }

    public static double[][] getDataArray(File f) throws IOException {
        return getDataArray(f, 1);
    }

    public static double[][] getDataArray(File f, int numFirst) throws IOException {

        BufferedReader r = new BufferedReader(new FileReader(f));
        StringTokenizer st = new StringTokenizer(r.readLine());
        st.nextToken();
        for (int i = 1; i < numFirst; i++) {
            st.nextToken();
        }
        int numData = 0;
        while (st.hasMoreTokens()) {
            st.nextToken();
            numData++;
        }
        r.close();
        r = new BufferedReader(new FileReader(f));
        double[][] result = new double[getLines(f)][numData];
        for (int c = 0; c < result.length; c++) {

            st = new StringTokenizer(r.readLine());
            for (int i = 1; i < numFirst; i++) {
                st.nextToken();
            }
            st.nextToken();
            for (int d = 0; d < numData; d++) {
                result[c][d] = Double.parseDouble(st.nextToken());
            }
        }
        return result;
    }

    /*Data format:
     * Line 1: [name of network] [negative order of magnitude of parameter] [parameter] [number of hidden layer neurons] [10/number of training data sets]
     * Lines 2 through 11:  [ideal result of input data] [input data 1] [input data 1] [input data 3] ... [input data 16]
     * Line 12: blank
     * Repeat this format once for every set of example neural network data that you want to feed the metanetwork.  
     * Example:
     * IMAGE  2 .0569 30 .227
-1.0 1.0 0.0 1.0 0.0 0.0 1.0 0.0 1.0 1.0 0.0 1.0 0.0 0.0 1.0 0.0 1.0  
0.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 1.0 1.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0  
1.0 0.0 1.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 1.0 0.0  
1.0 0.0 1.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 0.0 0.0  
1.0 0.0 0.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 1.0 0.0  
1.0 0.0 1.0 0.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 0.0 0.0  
1.0 0.0 1.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 1.0 1.0  
1.0 0.0 1.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0 1.0 1.0 0.0 1.0 0.0 1.0 0.0  
1.0 0.0 1.0 0.0 0.0 1.0 0.0 1.0 1.0 1.0 1.0 1.0 0.0 0.0 0.0 1.0 0.0  
-1.0 0.0 1.0 0.0 0.0 0.0 1.0 1.0 1.0 0.0 1.0 1.0 0.0 0.0 0.0 1.0 0.0
     
     * (next dataset would start here)     * 
     */
    public static double[][][] getMetaNetData(File f) throws IOException {
        double[][][] trainingData = new double[2][][];
        trainingData[0] = new double[21][172];
        trainingData[1] = new double[21][2];
        BufferedReader r = new BufferedReader(new FileReader(createFile("MetaNetData")));
        for (int i = 0; i < trainingData[0].length; i++) {
            System.out.println("Data group " + i);
            double[] data = getSingleMetaData(r);
            System.arraycopy(data, 0, trainingData[0][i], 0, data.length - 2);
            System.arraycopy(data, data.length - 2, trainingData[1][i], 0, 2);
            r.readLine();
        }
        return trainingData;
    }

    public static double[] getSingleMetaData(BufferedReader r) throws IOException {

        StringTokenizer st = new StringTokenizer(r.readLine());
        st.nextToken();
        double[] result = new double[173];
        //result[173] = Double.parseDouble(st.nextToken())/4.5;
        result[172] = Math.log10(Double.parseDouble(st.nextToken()))/(-3);
        result[171] = Double.parseDouble(st.nextToken()) / 600;
        result[170] = Double.parseDouble(st.nextToken());
        for (int i = 0; i < 10; i++) {
            st = new StringTokenizer(r.readLine());
            System.out.println("Just read line " + (i+2));
            for (int j = 0; j < 17; j++) {
                result[17 * i + j] = Double.parseDouble(st.nextToken()) /10;
            }
        }
        return result;
    }
}
