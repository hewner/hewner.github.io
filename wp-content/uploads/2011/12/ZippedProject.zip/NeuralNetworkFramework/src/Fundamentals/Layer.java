package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Gil Goldshlager
 */
import java.lang.reflect.*;
public class Layer {

    Neuron[] neurons;

    public Layer(int numNeurons, Function function, int numPrev) {
        neurons = new Neuron[numNeurons];
        for (int i = 0; i < numNeurons; i++) {
            neurons[i] = new Neuron(function, numPrev);
        }
    }

    public Layer(int numNeurons, Neuron neuron) {
        neurons = new Neuron[numNeurons];
        for (int i = 0; i < numNeurons; i++) {
            neurons[i] = neuron.getClone();
        }
    }

    public Layer(Neuron[] n) {
        neurons = n;
    }

    public Layer(Neuron[] types, int[] num) {
        int numNeurons = 0;
        for (int i = 0; i < num.length; i++) {
            numNeurons += num[i];
        }
        neurons = new Neuron[numNeurons];
        int pos = 0;
        for (int t = 0; t < types.length; t++) {
            Class c = types[t].getClass();
            for (int i = 0; i < num[t]; i++) {
                neurons[pos] = types[t].getClone();
                //(Neuron)c.getEnclosingConstructor().newInstance();
                pos++;
            }
        }
    }

    public void setWeightsLikeInput() {
        for (int i = 0; i < neurons.length; i++) {
            for (int j = 0; j < neurons[i].inWeights.length; j++) {
                if (i != j) {
                    neurons[i].inWeights[j] = 0;
                } else {
                    neurons[i].inWeights[j] = 1;
                }
            }
        }
    }

    public void randomizeWeights() {
        for (int i = 0; i < neurons.length; i++) {
            for (int j = 0; j < neurons[i].inWeights.length; j++) {
                neurons[i].inWeights[j] = 2 * Math.random() - 1;
            }
        }
    }

    public double[][] getWeights() {
        double[][] weights = new double[neurons.length][];
        for (int i = 0; i < neurons.length; i++) {
            for (int j = 0; j < neurons[0].inWeights.length; j++) {
                weights[i] = neurons[0].getWeights();
            }
        }
        return weights;
    }

    public void setInWeights(double[][] weights) {
        for (int i = 0; i < neurons.length; i++) {
            for (int j = 0; j < weights[0].length; j++) {
                neurons[i].inWeights[j] = weights[i][j];
            }
        }
    }

    public void processInputs(double[] previousOut) {
        double currSum;
        for (int i = 0; i < neurons.length; i++) {
            currSum = 0;
            for (int j = 0; j < previousOut.length; j++) {
                currSum = currSum + neurons[i].inWeights[j] * previousOut[j];
            }
            neurons[i].setInput(currSum);
        }
    }

    public double[] getOutputs() {
        double[] results = new double[neurons.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = neurons[i].getOutput();
        }
        return results;
    }

    public void printWeights() {
        for (int i = 0; i < neurons.length; i++) {
            System.out.print("Neuron " + i + ": ");
            neurons[i].printWeights();
        }
    }
}
