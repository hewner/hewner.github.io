package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Gil Goldshlager
 */
public class Network {

    Layer[] layers;
    Data trainingData;
    
    //prints the data line by line, with one (output, input) pair on each line
    public void printData(){
        for(int i = 0; i < trainingData.getNumInputs(); i++){
            for(int j = 0; j < trainingData.getOutputLength(); j++){
                System.out.print(trainingData.getOutputEntry(i,j) + "-");
            }
            for(int j = 0; j < trainingData.getNumInputs(); j++){
                System.out.print(trainingData.getInputEntry(i,j) + "-");
            }
            System.out.println();
        }
    }
    
    /*Sets the layers and functions of the network
     @param layerSize an array containing the number of neurons in each layer
     @param functions an array containing the type of function that each layer should have
     */
   
    public void setStructure(int[] layerSize, Function[] functions){
        clearLayers();
        addLayer(new Layer(layerSize[0], functions[0], layerSize[0]));
        for(int i = 1; i < layerSize.length; i++){
           addLayer(new Layer(layerSize[i], functions[i], layerSize[i-1]));
        }
    }
    
    /*Prints all of the weights of the network, layer by layer
     */
    public void printWeights() {
        for (int i = 0; i < layers.length; i++) {
            System.out.print("Layer " + i + ": ");
            layers[i].printWeights();
        }
    }

    //Creates a network with no layers
    public Network() {
        layers = new Layer[0];
    }

    //randomly sets the weights of the network
    public void randomizeWeights() {
        for (int i = 1; i < layers.length; i++) {
            layers[i].randomizeWeights();
        }
        layers[0].setWeightsLikeInput();
    }

   /*gets the weights of the array
     @return an array of weights of the network, such that array[i][j][k] is the weight of the kth connection of the jth neuron of the ith layer
     */
    public double[][][] getWeights(){
        double[][][] weights = new double[layers.length][][];
        for(int i = 0; i < layers.length; i++){
            weights[i] = layers[i].getWeights();
        }
        return weights;
    }
    
    
    //Resets the layer array to an empty array of length 0
    public void clearLayers(){
        layers = new Layer[0];
    }

    /*Adds a layer to the network
     * @param layer the layer to be added     * 
     */
    public void addLayer(Layer layer) {
        Layer[] newLayers = new Layer[layers.length + 1];
        for (int i = 0; i < newLayers.length - 1; i++) {
            newLayers[i] = layers[i];
        }
        newLayers[newLayers.length - 1] = layer;
        layers = newLayers;
    }

    /*
     * computes the output for a given input, and returns and stores it in the last layer of the network
     @param input the array of values to be sent to the input layer
     @return the output values for the given input
     */
    public double[] compute(double[] input) {
       
        double[] currIn = input;
        layers[0].processInputs(currIn);
        for (int i = 1; i < layers.length; i++) {
            currIn = layers[i - 1].getOutputs();
            layers[i].processInputs(currIn);
        }
        return layers[layers.length - 1].getOutputs();
    }
    
    /*Gets the output for the values that were last inputted to the network\
     * @return the array of output values
     */
    public double[] getOutput(){
        Layer l = layers[layers.length-1];
        
        double[] result = new double[l.neurons.length];
        for(int i = 0; i < l.neurons.length; i++){
            result[i] = l.neurons[i].getOutput();
        }
        return result;
    }

    //Prints the output on a single line, and moves to the next line
     
    public void printOutput() {
        double[] output = layers[layers.length - 1].getOutputs();
        for (int i = 0; i < output.length; i++) {
            System.out.print(output[i] + " ");
        }
        System.out.println();
    }
}
