package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gil Goldshlager
 */
public interface Function {
    public double f(double input);
    
    public double dydx(double input);
}
