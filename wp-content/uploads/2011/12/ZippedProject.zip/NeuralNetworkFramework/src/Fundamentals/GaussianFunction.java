/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author Gil Goldshlager
 */
public class GaussianFunction implements Function{
    public double f(double x){
        if(x > 1){
            return 0;
        }
        return Math.exp(x-1);
    }
    public double dydx(double x){
        if(x>1){
            return 1;
        }
        return Math.exp(x-1);
    }
}
