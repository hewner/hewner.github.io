/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;


public class LimitedSigmoidalFunction implements Function{
    double limit;
    double c;
    public LimitedSigmoidalFunction(double constant, double lim){
        c = constant;
        limit = lim;
    }
    
    public LimitedSigmoidalFunction(double lim){
        c = 1;
        limit = lim;
    }
       
    public LimitedSigmoidalFunction(){
        c = 1;
        limit = 6;
    }
    
    public double f(double x){
        if(x > limit){
            return f(limit-.1);
        }
        if(x < -limit){
            return f(-limit+.1);
        }
        double result = 1/(1 + Math.exp(-x* c));
        return result;
    }
    
    public double dydx(double x){
        if(x > limit){
            return dydx(limit-.1);
                    }
        if(x < -limit){
            return dydx(-limit+.1);
        }
        double result = c*Math.exp(c*x);
        result /= Math.pow((1+ Math.exp(c*x)),2);
        return result;
    }
}
