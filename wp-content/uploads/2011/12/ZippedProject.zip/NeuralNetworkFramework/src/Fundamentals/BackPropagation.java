/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author Gil Goldshlager
 */
public class BackPropagation {
    
    //the largest sum-squared-error that will be accepted for a trained network
    double acceptableErr;
    
    Data trainingData;
    
    //the array that stores the error of each neuron from its ideal value
    double[][] error;
    
    private Network network;
    
    //the value that controls how much the weights of the network will be cahnged to account for error
    //smaller = less change
    private double weightLimiter;
    
    //the value that controls how much the natural bias ("default value") of each neuron will be changed to account for error
    double biasLimiter;
    
    //the index of the last data point that should be used for training rather than verification
    int maxTrain;

    /*
     @param net the associated network
     @param data the training data
     @param maxTraining the index of the final piece of data that should be used to train the network
     @param limit the value of the limiting constant for changing the weight
     @param error the value of the acceptable error
     */
    public BackPropagation(Network net, Data data, int maxTraining, double limit, double error) {
        trainingData = data;
        maxTrain = maxTraining;
        acceptableErr = error;
        network = net;
        weightLimiter = limit;
        biasLimiter = weightLimiter * weightLimiter;
    }

    public int getMaxTrain() {
        return maxTrain;
    }

    public double[] getOutputVector(int num){
        return trainingData.getOutputVector(num);
    }
    
    public double[] getInputVector(int num) {
        return trainingData.getInputVector(num);
    }

    public double[][] getInput() {
        return trainingData.getInputData();
    }

    public double[][] getOutput() {
        return trainingData.getOutputData();
    }

    public void setAcceptableErr(double in) {
        acceptableErr = in;
    }

    //automatically sets the biaslimiter to the square of the weightlimiter so that it cannot have a large effect on the training- this was found to be a good
    //approximate value 
    public void setLimiter(double a) {
        weightLimiter = a;
        biasLimiter = a * a;
    }

    public double getWeightLimiter() {
        return weightLimiter;
    }

    //sets the error matrix to 0
    public void resetError() {
        for (int i = 0; i < error.length; i++) {
            for (int j = 0; j < error[i].length; j++) {
                error[i][j] = 0;
            }
        }

    }

    //recreates the error matrix for the current structure of the network 
    public void createError() {
        error = new double[network.layers.length][];
        for (int i = 0; i < error.length; i++) {
            error[i] = new double[network.layers[i].neurons.length];
        }
    }

    /*fills the error network with appropriate values for a given desired output
     @param numOutput the index in the training data array of the output used
   */
    public void calculateErrors(int numOutput) {
        if (error == null) {
            createError();
        }
        resetError();

        Neuron thisNeuron;
        for (int i = 0; i < network.layers[network.layers.length - 1].neurons.length; i++) {
            thisNeuron = network.layers[network.layers.length - 1].neurons[i];
            error[network.layers.length - 1][i] = (trainingData.getOutputEntry(numOutput,i) - thisNeuron.output) * (thisNeuron.getDerivative());
        }
        for (int l = network.layers.length - 2; l >= 0; l--) {
            for (int n = 0; n < network.layers[l].neurons.length; n++) {
                thisNeuron = network.layers[l].neurons[n];
                for (int dest = 0; dest < network.layers[l + 1].neurons.length; dest++) {
                    //change to multiplication by derivative
                    error[l][n] += error[l + 1][dest] * (network.layers[l + 1].neurons[dest].inWeights[n]) * thisNeuron.getDerivative();
                }
                //System.out.println("Error at layer " + l + " and neuron " + n + ": " + error[l][n]);
            }
        }
    }

    /*increases the values of the error array based on the errors of a given output set
    @param numOutput the index in the training data array of the output used
    */
    public void addToErrors(int numOutput) {
        //creates thisError array to store this set
        double[][] thisError = new double[network.layers.length][];
        for (int i = 0; i < thisError.length; i++) {
            thisError[i] = new double[network.layers[i].neurons.length];
        }
        if (error == null) {
            createError();
        }

        Neuron thisNeuron;
        for (int i = 0; i < network.layers[network.layers.length - 1].neurons.length; i++) {
            thisNeuron = network.layers[network.layers.length - 1].neurons[i];
            thisError[network.layers.length - 1][i] = (trainingData.getOutputEntry(numOutput, i) - thisNeuron.output) * (thisNeuron.getDerivative());
            error[network.layers.length-1][i] += thisError[network.layers.length - 1][i];
        }
        for (int l = network.layers.length - 2; l >= 0; l--) {
            for (int n = 0; n < network.layers[l].neurons.length; n++) {
                thisNeuron = network.layers[l].neurons[n];
                for (int dest = 0; dest < network.layers[l + 1].neurons.length; dest++) {
                    thisError[l][n] += thisError[l + 1][dest] * (network.layers[l + 1].neurons[dest].inWeights[n]) * thisNeuron.getDerivative();
                }
                error[l][n] += thisError[l][n];
                //System.out.println("Error at layer " + l + " and neuron " + n + ": " + error[l][n]);
            }
        }
    }
    
    //updates the weights based on the error array to attempt to bring the network closer to ideal
    public void updateWeights() {
        Neuron destNeuron, startNeuron;
        for (int l = network.layers.length - 1; l > 0; l--) {
            for (int dest = 0; dest < network.layers[l].neurons.length; dest++) {
                destNeuron = network.layers[l].neurons[dest];
                for (int start = 0; start < network.layers[l - 1].neurons.length; start++) {
                    startNeuron = network.layers[l - 1].neurons[start];
                    startNeuron.setOffset(startNeuron.getOffset() + error[l - 1][start] * biasLimiter);
                    destNeuron.inWeights[start] += error[l][dest] * startNeuron.input * weightLimiter;
                    if(destNeuron.inWeights[start] > 10){
                       // destNeuron.inWeights[start] = 10;
                    }
                    if(destNeuron.inWeights[start] < -10){
                        //destNeuron.inWeights[start] = -10;
                    }
                }
            }
        }
    }
      
    //trains the network, updating weights based on each individual data point
    public int trainNetwork() {
        double currentError;
        int epoch = 0;
        LearnLoop:
        while (true) {
            trainingEpoch();
            currentError = getSumSquaredError(0, maxTrain);
            if (currentError < acceptableErr) {
                break LearnLoop;
            }
            System.out.println(currentError);
            epoch++;
        }
        return epoch;
    }
    
    //trains the network, accumulating the error of the entire data set and updating weights accordingly
    public int cumulativeTrainNetwork() {
        double currentError;
        int epoch = 0;
        LearnLoop:
        while (true) {
            //trainingEpoch();
            cumulativeTrainingEpoch();
            currentError = getSumSquaredError(0, maxTrain);
            if (currentError < acceptableErr) {
                break LearnLoop;
            }
            System.out.println(currentError);
            epoch++;
        }
        return epoch;
    }

    //executes a single iteration of the training process- computes output, calculates error, updates weights
    public void trainingEpoch() {
        for (int i = 0; i < trainingData.getNumInputs(); i++) {
            network.compute(trainingData.getInputVector(i));
            calculateErrors(i);

        updateWeights();
        }
    }
    
     public void printData(){
        for(int i = 0; i < trainingData.getInputLength(); i++){
            for(int j = 0; j < trainingData.getOutputLength(); j++){
                System.out.print(trainingData.getOutputEntry(i,j) + "+");
            }
            for(int j = 0; j < trainingData.getInputLength(); j++){
                System.out.print(trainingData.getInputEntry(i,j) + "+");
            }
            System.out.println();
        }
    }
    
     //executes a single interation of the cumulative training process- computes output and calculates error for all data points, 
     //then updates weights
    public void cumulativeTrainingEpoch() {
       createError();
        for (int i = 0; i < trainingData.getNumInputs(); i++) {
            network.compute(trainingData.getInputVector(i));
            addToErrors(i);
        }
        updateWeights();
    }

    public double[][] getTrainingInput() {
        return trainingData.getInputData();
    }

    public double[][] getTrainingOutput() {
        return trainingData.getOutputData();
    }

    public double[] getTrainingInput(int i) {
        return trainingData.getInputVector(i);
    }

    public double[] getTrainingOutput(int i) {
        return trainingData.getOutputVector(i);
    }

    public String getNetworkData() {
        String result = "";
        result = result.concat("" + trainingData.getNumInputs());
        int numOutParam = trainingData.getOutputLength();
        int numInParam = trainingData.getInputLength();
        result = result.concat(" " + numInParam);
        result = result.concat(" " + numOutParam);
        return result;
    }

    //trains the network but cuts it off if it reaches a certain maximum number of training epochs
    public int trainNetwork(int maxEpoch) {
        double currentError;
        int epoch = 0;
        LearnLoop:
        while (true) {
            trainingEpoch();
            currentError = getSumSquaredError(0, maxTrain);
            if (currentError < acceptableErr) {
                break LearnLoop;
            }
            System.out.println(currentError);
            epoch++;
            if (epoch > maxEpoch) {
                return -1;
            }
        }
        return epoch;
    }

    public Network getNetwork() {
        return network;
    }

    
    /*trains the network with a variety of weightlimiters to find which one is best
     * Cuts off the network whenever if exceeds the previously attained minimum number of epochs
     @param workableVal a value that is known to take a reasonable amount of time to train- ensures that the network will not go on forever with a bad value
     @param minVal the minimum value to test
     @param maxval the maximum value to test
     @param numVals the number of intermediate values to test
     @return the entire array of tested values and resulting number of epochs 
     */
    public double[][] findBestLimiter(double workableVal, double minVal, double maxVal, int numVals) {

        double bestVal = workableVal;
        double[][] info = new double[numVals + 1][2];
        int pos = 0;
        setLimiter(workableVal);
        network.randomizeWeights();
        int minEpoch = trainNetwork();
        int epoch;
        info[pos][0] = workableVal;
        info[pos][1] = minEpoch;
        for (double val = minVal; val < maxVal; val += (maxVal - minVal) / numVals) {
            network.randomizeWeights();
            setLimiter(val);
            epoch = trainNetwork(minEpoch * 2);
            info[pos][1] = epoch;
            info[pos][0] = val;
            pos++;
            if (epoch < minEpoch && epoch != -1) {
                minEpoch = epoch;
                bestVal = val;
            }
            System.out.println("Limiter: " + val + ", Epoch: " + epoch);
        }
        for (int i = 0; i < numVals; i++) {
            System.out.println("Value: " + info[i][0] + ", Epochs: " + info[i][1]);
        }

        System.out.println("Best value: " + bestVal + ", Number of Epochs: " + minEpoch);

        return info;
    }
    
    /*trains the network with a variety of weightlimiters to find which one is best
     * Does NOT cut off the network whenever if exceeds the previously attained minimum number of epochs
     @param workableVal a value that is known to take a reasonable amount of time to train- ensures that the network will not go on forever with a bad value
     @param minVal the minimum value to test
     @param maxval the maximum value to test
     @param numVals the number of intermediate values to test
     @return the entire array of tested values and resulting number of epochs 
     */
    public double[][] findBestLimiterNoCutoff(double workableVal, double minVal, double maxVal, int numVals) {

        double bestVal = workableVal;
        double[][] info = new double[numVals + 1][2];
        int pos = 0;
        setLimiter(workableVal);
        network.randomizeWeights();
        int minEpoch = trainNetwork();
        int epoch;
        info[pos][0] = workableVal;
        info[pos][1] = minEpoch;
        for (double val = minVal; val < maxVal; val += (maxVal - minVal) / numVals) {
            network.randomizeWeights();
            setLimiter(val);
            epoch = trainNetwork();
            epoch = (epoch + trainNetwork()) / 2;
            info[pos][1] = epoch;
            info[pos][0] = val;
            pos++;
            if (epoch < minEpoch && epoch != -1) {
                minEpoch = epoch;
                bestVal = val;
            }
            System.out.println("Limiter: " + val + ", Epoch: " + epoch);
        }
        for (int i = 0; i < numVals; i++) {
            System.out.println("Value: " + info[i][0] + ", Epochs: " + info[i][1]);
        }

        System.out.println("Best value: " + bestVal + ", Number of Epochs: " + minEpoch);

        return info;
    }

    /*Determines based on the verification data how successful the network's training process was
     @param startPos the index of the first piece of data to be used as verification
     @param endPos the index of the last piece of data to be used as verification
     @param maxDiff the maximum difference between the ideal and calculated values that will be considered correct
     @return a boolean array whose entries record which of the verification data points were calculated correctly by the network
     */
    public boolean[] getResults(int startPos, int endPos, double maxDiff) {
        boolean[] result = new boolean[endPos - startPos + 1];
        for (int i = 0; i < result.length; i++) {
            network.compute(trainingData.getInputVector(i + startPos));
            double[] calculated = network.getOutput();
            double[] ideal = trainingData.getOutputVector(i+startPos);
            result[i] = true;
            for (int j = 0; j < ideal.length; j++) {
                System.out.println("Ideal: " + ideal[j] + ", Calculated: " + calculated[j]);
                if (Math.abs(calculated[j] - ideal[j]) > maxDiff) {
                    result[i] = false;
                }
            }
        }
        return result;
    }
    
    
    /*Returns the sum squared error for a given sequence of the trainingData
     * @param: start the index of the first piece of data to be analyzed
     * @param: end the index of the last piece of data to be analyzed
     * @param trainingData the network
     */
    public double getSumSquaredError(int start, int end) {
        Neuron[] outputs = network.layers[network.layers.length - 1].neurons;
        double error = 0;
        double thisErr;
        for (int sample = start; sample < end; sample++) {
            network.compute(trainingData.getInputVector(sample));
            for (int i = 0; i < outputs.length; i++) {
                thisErr = outputs[i].output - trainingData.getOutputEntry(sample,i);
                error += thisErr * thisErr;
            }
        }
        return error;
    }
}
