/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

import Fundamentals.Function;

/**
 *
 * @author Gil Goldshlager
 */
public class CompetetiveFunction implements Function {

    Layer layer;
    int neurNum;

    public double f(double x) {
        layer.neurons[neurNum].output = x;
        for (int i = 0; i < layer.neurons.length; i++) {
            if (layer.neurons[i].output > x) {
                return 0;
            }
        }
        return 1;
    }
    
    public void setInput(double x){
        layer.neurons[neurNum].input = x;
    }
    
    public double dydx(double x){
        return 1;
    }
}
