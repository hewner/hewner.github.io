/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author Gil Goldshlager
 */
public class LimitedGaussianFunction implements Function{
     double limit;
    double c;
    public LimitedGaussianFunction(double constant, double lim){
        c = constant;
        limit = lim;
    }
    
    public LimitedGaussianFunction(double lim){
        c = 1;
        limit = lim;
    }
       
    public LimitedGaussianFunction(){
        c = 1;
        limit = 6;
    }
    
    public double f(double x){
        if(x > limit){
            return f(limit);
        }
        if(x < -limit){
            return f(-limit);
        }
        return Math.exp(x-1);
    }
    
    public double dydx(double x){
        if(x > limit){
            return dydx(limit);
                    }
        if(x < -limit){
            return dydx(-limit);
        }
        return Math.exp(x-1);
    }
}
