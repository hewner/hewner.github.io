/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author Gil Goldshlager
 */
public class NormalFunction implements Function{
    
    private double fRaw(double x){
         return Math.exp(-x*x);
    }
    
    private double dydxRaw(double x){
        
        return -2*x*Math.exp(-x*x);
    }
    public double f(double x){
        if(x < 0){
            x -= .2;}
        if(x > 0){
            x+= .2;
            
        }
        
        if(x > 4){
            return fRaw(4);
        }
        if(x<-4){
            return fRaw(-4);
        }
        return fRaw(x);
        
    }
    
    public double dydx(double x){
        if(x < 0){
            x-= .2;
        }
        if(x > 0){
            x+= .2;
        }
        if(x>4){
            return dydxRaw(4);
        }
        if(x < -4){
            return dydxRaw(4);
        }
        return dydxRaw(x);
    }
}
