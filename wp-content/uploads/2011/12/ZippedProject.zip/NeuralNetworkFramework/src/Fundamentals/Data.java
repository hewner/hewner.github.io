/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author Gil Goldshlager
 */
public class Data {
    double[][] input;
    double[][] output;
    
    public Data(double[][] in, double[][] out){
        input = in;
        output = out;
    }
    
    public double[][] getInputData(){
        return input;
    }
    
    public double[][] getOutputData(){
        return output;
    }
    
    //gets a row of input
    public double[] getInputVector(int i){
        return input[i];
    }
    
    //gets a row of output
    public double[] getOutputVector(int i){
        return output[i];
    }
    
    //gets a single entry of input- index of row/vector, then index ofvalue
    public double getInputEntry(int i, int j){
        return input[i][j];
    }
    
    //gets a single entry of output- index of row/vector, then index of value
    public double getOutputEntry(int i, int j){
        return output[i][j];
    }
 
    //gets the length of each input vector (number of entries in each input vector)
    public int getInputLength(){
        return input[0].length;
    }
    
    //gets the total number of input vectors
    public int getNumInputs(){
        return input.length;
    }
    
    //gets the length of each output vector(number of entries)
     public int getOutputLength(){
        return output[0].length;
    }
    
     //gets the total number of output vectors
    public int getNumOutputs(){
        return output.length;
    }
    
    //scales the input vectors to each have a minimum entry of minVal and a maximum entry of maxVal
    public void scaleInputVectors(double minVal, double maxVal){
        scaleRows(input, minVal, maxVal);
    }
    
     //scales the output vectors to each have a minimum entry of minVal and a maximum entry of maxVal
    public void scaleOutputVectors(double minVal, double maxVal){
        input = scaleColumns(input, minVal, maxVal);
    }
    
     //scales the input columns- e.g. the set of first entries of all of the input vectors- to each have a minimum value of minVal and a maximum value of maxVal
    public void scaleInputColumns(double minVal, double maxVal) {
        input = scaleColumns(input, minVal, maxVal);
    }
    
         //scales the output columns- e.g. the set of first entries of all of the input vectors- to each have a minimum value of minVal and a maximum value of maxVal
    public void scaleOutputColumns(double minVal, double maxVal){
        output = scaleColumns(output, minVal, maxVal);
    }
    
    
    private void scaleRows(double[][] data, double minVal, double maxVal){
        for(int i = 0; i < data.length; i++){
            scale(data[i], minVal, maxVal);
        }
    }
    
    private double[][] scaleColumns(double[][] data, double minVal, double maxVal){
        double[][] trans = transpose(data);
        scaleRows(trans, minVal, maxVal);
        return transpose(trans);
    }
    
    //normalizes input vectors- that is, makes them have a length of 1
    //Length calculated by sqrt(x_1^2+x_2^2+...+x_n^2)
    public void normalizeInputVectors(){
        for(int i = 0; i < input.length; i++){
            normalize(input[i]);
        }
    }
    
    //normalizes output vectors- that is, makes them have a length of 1
    //Length calculated by sqrt(x_1^2+x_2^2+...+x_n^2)
    public void normalizeOutputVectors(){
        for(int i = 0; i < output.length; i++){
            normalize(output[i]);
        }
    }
    
    public void scale(double[] data, double minVal, double maxVal){
        double max = data[0], min = data[0];
        for(int i = 1; i < data.length; i++){
            if(data[i] > max){
                max = data[i];
            }
            if(data[i] < min){
                min = data[i];
            }
        }
        double shift = (max*minVal - min*maxVal)/(max - min);
        double scale = (maxVal - minVal)/(max - min);
        for(int i = 0; i < data.length; i++){
            data[i]*= scale;
            data[i]+= shift;
        }
    }
    
    public void normalize(double[] data){
        double mag = 0;
        for(double d: data){
            mag += d*d;
        }
        mag = Math.pow(mag,1/2);
        for(int i = 0; i < data.length; i++){
            data[i]/= mag;
        }
    }
    
    //makes a new array whose rows are the columns of teh input array and whose columns are the rows of the input array
    private double[][] transpose(double[][] matrix){
        double[][] result = new double[matrix[0].length][matrix.length];
        for(int i = 0; i < matrix.length; i++){
            for(int j = 0; j < matrix[0].length; j++){
                result[j][i] = matrix[i][j];
            }
        }
        return result;
    }
    
    //gets a random binary string of given length
    public static double[] getRandomBinary(int length) {
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            if (Math.random() > .5) {
                result[i] = 0;
            } else {
                result[i] = 1;
            }
        }
        return result;
    }
}
