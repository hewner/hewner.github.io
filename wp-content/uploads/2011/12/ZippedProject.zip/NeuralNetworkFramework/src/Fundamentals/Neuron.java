package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Gil Goldshlager
 */
public class Neuron {

    Function function;
    double[] inWeights;
    double input;
    double output;
    double offset;

    public Neuron(Function f, int numIn) {
        function = f;
        input = 0;
        output = 0;
        inWeights = new double[numIn];
        offset = 0;
    }
    
    public void setNumPrev(int numPrev){
        inWeights = new double[numPrev];
    }
    
    public double[] getWeights(){
        double[] w = new double[inWeights.length];
        for(int i = 0; i < w.length; i++){
            w[i] = inWeights[i];
        }
        return w;
    }

    public void cloneParts() {
        inWeights = inWeights.clone();
    }

    protected Neuron clone() {
        Neuron result = this;
        try {
            result = (Neuron) super.clone();
            result.cloneParts();
        } catch (CloneNotSupportedException e) {
        }
        return result;
    }

    public Neuron getClone() {
        return clone();
    }

    public void setOffset(double o) {
        offset = o;
    }

    public double getOffset() {
        return offset;
    }

    public double getWeightSum() {
        double sum = 0;
        for (int i = 0; i < inWeights.length; i++) {
            sum += inWeights[i];
        }
        return sum;
    }

    public double getOutput(double input) {
        return function.f(offset + input);
    }

    public double getDerivative(double in) {
        return function.dydx(in);
    }

    public double getDerivative() {
        return function.dydx(input);
    }

    public void setWeights(double[] w) {
        inWeights = w;
    }

    public void setNumWeights(int num) {
        inWeights = new double[num];
    }

    public double getOutput() {
        return output;
    }

    public double getInput() {
        return input;
    }

    public void setInput(double i) {
        input = i;
        output = getOutput(i);
    }
    
    public void printWeights(){
        for(int i = 0; i < inWeights.length; i++){
            System.out.println("Weight " + i + ": " + inWeights[i]);
        }
    }
}
