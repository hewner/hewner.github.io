package Fundamentals;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gil Goldshlager
 */
public class SigmoidalFunction implements Function{
    double c;
    public SigmoidalFunction(double constant){
        c = constant;
    }
    
    public SigmoidalFunction(){
        c = 1;
    }
    
    public double f(double x){
        double result = 1/(1 + Math.exp(-x* c));
        return result;
    }
    
    public double dydx(double x){
        double result = c*Math.exp(c*x);
        result /= Math.pow((1+ Math.exp(c*x)),2);
        return result;
    }
}
