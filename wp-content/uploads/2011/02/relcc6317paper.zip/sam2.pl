% -*- Mode: Prolog -*-

replace_in(Val, NewVal, List, Outlist) :-
	append(A,[Val|B],List),
	append(A,[NewVal|B],Outlist).

goal_satisfied(Goals,Story) :-
	msort(Goals, Sorted),
	goal_satisfied_s(Sorted, Story).


replacable([swordsmanship,S], [aggressive,S]).
replacable([sword,S], [aggressive,S]).
replacable([findlove,S], [communication,S]).

different_gender(S1,S2) :-
	gender(S1,G1),
	gender(S2,G2),
	G1 \= G2.

% add goals here

goal_satisfied_s([[findlove,S1],[swordsmanship,S2]], [sword_finds_love(S1,S2)]) :-
	different_gender(S1,S2).
goal_satisfied_s([[swordsmanship,S1],[swordsmanship,S2]], [duel(S1,S2)]).
goal_satisfied_s([[aggressive,S1],[aggressive,S2]],[killstuff(S1,S2)]).
goal_satisfied_s([[aggressive,S1],[communication,S2]],[protect_mission(S1,S2)]).
goal_satisfied_s([[aggressive,S1],[swordsmanship,S2]], [ally_at_risk_for_secret(S1,S2)]).
goal_satisfied_s([[sword,S1],[sword,S2]],[two_blades_make_map(S1,S2)]).
goal_satisfied_s([[communication,S1],[sword,S2]],[scholar_demon_room(S1,S2)]).
attribute_gained(scholar_demon_room(N11,N2)) :-
	update_attr(N2,swordpower,demonic).
goal_satisfied_s([[communication,S1],[sword,S2]],[purify(S1,S2)]) :-
	attr_value(S2,swordpower,demonic).
goal_satisfied_s([[aggressive,S1],[enemy(N1),S2]],[battle_royale(S1,S2)]) :-
	samname(S1,N2),
	N2 = N1.
goal_satisfied_s([[aggressive,S1],[enemy(N1),S2]],[track-enemy(S1,S2)]) :-
	samname(S1,N2),
	N2 \= N1.

goal_satisfied_s(Goals, Story) :-
	replace_in(From, To,Goals, NewGoals),
	replacable(From, To),
	goal_satisfied(NewGoals, NewStory),
	Story = [generalize(From, To)|NewStory].
attribute_gained(X).

begin_sam(Name,Gender,Goal) :-
	begin_sam(Name,Gender,Goal,Result).
begin_sam(Name, X, Y, Z) :-
	sam_named(Name,Sam),
	write('That name is already used.'),
	!, fail.
begin_sam(Name,Gender,Goal,Sam) :-
	Sam = sam(Name,Gender,Goal,[]),
	get_sams(Sams),
	set_sams([Sam | Sams]), 
	write('Created a new samurai named '),
	write(Name),
	write('.').

set_sams(NewSams) :-
	recorded(sams,Sam,Location),
	erase(Location),
	recorda(sams,NewSams).
set_sams(NewSams) :-
	recorda(sams,NewSams).

get_sams(Sams) :-
	recorded(sams,Sams).
get_sams([]).

update_goal(Name,NewGoal) :-
	get_sams(Sams),
	replace_in(sam(Name,Gender,OldGoal,OldAttrib),sam(Name,Gender,NewGoal,OldAttrib),Sams,NewSams),
	set_sams(NewSams).

update_attr_list(Key,Value,List,NewList) :-
	member([Key,OldVal],List),
	replace_in([Key,OldVal],[Key,Value],List,NewList).
update_attr_list(Key,Value,List,[[Key,Value]|List]).

attr_value(Sam,Key,Value) :-
	Sam = sam(X,Y,Z,AttrList),
	member([Key,Value],AttrList).

update_attr(Name,Key,Value) :-
	get_sams(Sams),
	replace_in(sam(Name,Gender,OldGoal,OldAttrib),sam(Name,Gender,OldGoal,NewAttrib),Sams,NewSams),
	update_attr_list(Key,Value,OldAttrib,NewAttrib),
	set_sams(NewSams).

sam_named(Name,Sam) :-
	get_sams(Sams),
	Sam = sam(Name,X,Y,Z),
	member(Sam,Sams).

story_raw(Sam1,Sam2, Output) :-
	goal(Sam1,Goal1),
	goal(Sam2,Goal2),
	goal_satisfied([[Goal1,Sam1],[Goal2,Sam2]],Output).

story_with(N,N) :-
	write('Use two different sams.'),
	!,fail.
story_with(Name1,Name2) :-
	story_with(Name1,Name2,Story).
story_with(Name1,Name2,Story) :-
	sam_named(Name1,Sam1),
	sam_named(Name2,Sam2),
	story_raw(Sam1,Sam2,Story),
	express_story(Story).

pronoun(sam(X,male,Y,Z),'his').
pronoun(sam(X,female,Y,Z),'her').
gender(sam(X,Gen,Y,Z),Gen).
samname(sam(X,Y,Z,Z2),X).
goal(sam(X,Y,Z,Z2),Z).

:-
	write('Welcome to the Mike Sam Simulation!\n\n'),
	write('To create a new samauri character, try something like:\n\n'),
	write('begin_sam(mike,male,sword).\n\n'),
	write('Then when you have 2 characters, start a story about them like this:\n\n'),
	write('story_with(mike,ben).').
