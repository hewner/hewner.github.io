% -*- Mode: Prolog -*-

express_goal(Sam) :-
	goal(Sam,swordsmanship),
	pronoun(Sam,Pronoun),
	samname(Sam,Name),
	write(Name),
	write(' chose to practice '),
	write(Pronoun),
	write(' swordsmanship and grow stronger.\n').
express_goal(Sam) :-
	goal(Sam,findlove),
	pronoun(Sam,Pronoun),
	samname(Sam,Name),
	write(Name),
	write(' chose to seek '),
	write(Pronoun),
	write(' true love in the wide world.\n').
express_goal(Sam) :-
	goal(Sam,sword),
	pronoun(Sam,Pronoun),
	samname(Sam,Name),
	write(Name),
	write(' chose to uncover the secrets of '),
	write(Pronoun),
	write(' mysterious sword.\n').

enumerate_goals([]).
enumerate_goals([Sam|Rest]) :-
	express_goal(Sam),
	enumerate_goals(Rest).

express_story_element(duel(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write('Both travelling for seperate missions '),
	write(N1),
	write(' and '),
	write(N2),
	write(' come across each other in the wilderness.  Impressed with each'),
	write(' other, they decide to have a duel.\n\n'),
	write('If things went poorly, update_goal(name,enemy(othername)) might be a potential followup')
	,!.

express_story_element(sword_finds_love(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N2),
	write(' is training at a dojo, but can\'t master a difficult technique.  '),
	write(N1),
	write(' insightfully sees '),
	write(N2),
	write('\'s problem but playfully refuses to tell'),
	write('...at least at first.\n'),!.

express_story_element(killstuff(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N1),
	write(' and '),
	write(N2),
	write(' meet in a wasteland, hunting oni.  They decide to band together.\n'),!.

express_story_element(protect_mission(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N2),
	write(' is on a diplomatic mission to a provence ravaged by mauraders.  '),
	write(N1),
	write(' as a skilled fighter, is employed for '),
	write(N2),
	write('\'s protection.\n'),!.

express_story_element(battle_royale(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N2),
	write(' tracks '),
	write(N1),
	write(' down and they have it out.\n'),!.


express_story_element(ally_at_risk_for_secret(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N1),
	write(' has been tasked by his lord to clear out the bandits in a nearby pass.  '),
	write(N2),
	write(', who overhears the assignment, asks to come along as an opportunity to train.'),!.

express_story_element(two_blades_make_map(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N1),
	write(' and '),
	write(N2),
	write(' meet, after hearing that their two blades are strangely similar.  When the blades a placed side by side, a map to some old ruins is revealed.'),!.

express_story_element(scholar_demon_room(S1,S2)) :-
	samname(S1, N1),
	samname(S2, N2),
	write(N1),
	write(' is acting as a translator for a mysterious wizard interested in '),
	write(N2),
	write('\'s sword.  Investigation reveals that the sword is actually of demonic orgin, and that the wizard intends to steal it.\n\n'),
	write('This story has attributes.  say attribute_gained('),
	write(N1),
	write(','),
	write(N2),
	write(') to add appropiate attributes.'),!.

express_story_element(generalize([findlove, S1],[communication, S1])) :-
	samname(S1,N1),
	write('Seeking love, '),
	write(N1),
	write(' begins to find excuses to work on diplomatic assignments away from home.\n').

express_story_element(generalize([swordsmanship, S1],[aggressive, S1])) :-
	samname(S1,N1),
	write('Seeking to improve his skills, '),
	write(N1),
	write(' takes on dangerous assignments whenever possible.\n').

express_story_element(generalize([sword, S1],[aggressive, S1])) :-
	samname(S1,N1),
	write('Seeking to reveal his sword\'s powers in battle '),
	write(N1),
	write(' takes on dangerous assignments whenever possible.\n').


express_story_element(Unk) :-
	write('Unknown story element: '),
	write(Unk),
	write('\n').


express_story([Element|Rest]) :-
	express_story_element(Element),
	express_story(Rest).
express_story([]).
