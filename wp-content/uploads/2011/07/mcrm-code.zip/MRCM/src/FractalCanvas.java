import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.Vector;


public class FractalCanvas extends Canvas implements MouseMotionListener {

	public static final int WIDTH = 500;
	public static final int BORDER = 5;
	
	protected BufferedImage source;
	protected BufferedImage target;
	protected Vector<AffineTransform> transforms;
	protected int zoomLevel;
	
	public FractalCanvas(BufferedImage initialImage)
	{
		setPreferredSize(new Dimension(WIDTH*2+8,WIDTH+4));

		int initialHeight = initialImage.getHeight();
		int initialWidth = initialImage.getWidth();
		float xScale = (float) WIDTH/initialWidth;
		float yScale = (float) WIDTH/initialHeight;
		AffineTransform trans = initialPosition();
		trans.scale(xScale, yScale);

		
		
		target = emptyImage();
		Graphics2D sourceG = target.createGraphics();
		sourceG.drawImage(initialImage, trans, null);
		
		transforms = new Vector<AffineTransform>();
		AffineTransform startingTransform = new AffineTransform();
		startingTransform.translate((float) 0.5, (float) 0.5);
		startingTransform.scale(.5, .5);
		transforms.add(startingTransform);

		startingTransform = new AffineTransform();
		startingTransform.translate((float) 0.0, (float) 0.5);
		startingTransform.scale(.5, .5);
		transforms.add(startingTransform);

		startingTransform = new AffineTransform();
		startingTransform.translate((float) 0.25, (float) 0.0);
		startingTransform.scale(.5, .5);
		System.out.println(startingTransform.toString());
		transforms.add(startingTransform);
		
		doStep();
		
		zoomLevel = 0;
		addMouseMotionListener(this);
	}
	
	
	protected BufferedImage emptyImage()
	{
		return new BufferedImage(WIDTH*(BORDER*2 + 1), WIDTH*(BORDER*2 + 1), BufferedImage.TYPE_INT_ARGB);
	}
	
	protected AffineTransform initialPosition()
	{
		AffineTransform startingTransform = new AffineTransform();
		startingTransform.translate(BORDER*WIDTH, BORDER*WIDTH);
		return startingTransform;
		
	}
	
	public void doStep()
	{
		source = target;
		target = emptyImage();
		Graphics2D targetG = target.createGraphics();
		
		
		AffineTransform fractalTrans = new AffineTransform();
		fractalTrans.translate(BORDER*WIDTH, BORDER*WIDTH);
		
		fractalTrans.scale((float) WIDTH, (float) WIDTH);
		
		//now custom stuff
		for(AffineTransform t : transforms)
		{
			AffineTransform temp = new AffineTransform(fractalTrans);
			
			temp.concatenate(t);
			temp.translate(-BORDER, -BORDER);
			
			
			temp.scale((float) 1/WIDTH, (float) 1/WIDTH);
			targetG.drawImage(source, temp, null);
		}	
	}
	
	
	public void paint(Graphics _g)
	{
		Graphics2D g = (Graphics2D) _g;
		g.drawRect(0,0,WIDTH+2,WIDTH+2);
		g.drawRect(WIDTH + 5, 0, WIDTH+2, WIDTH+2);
		
		drawImageForZoom(g, source, 1, 1, zoomLevel);
		drawImageForZoom(g, target, 507, 1, zoomLevel);
		
	}

	public void drawImageForZoom(Graphics2D g, BufferedImage image, int x, int y, int zoom)
	{
		int numWidths = zoom*2 + 1;
		int offset = (numWidths/2)*WIDTH;
		BufferedImage unscaled = image.getSubimage(BORDER*WIDTH-offset, BORDER*WIDTH-offset, WIDTH*numWidths, WIDTH*numWidths);
		g.drawImage(unscaled,x,y,x+WIDTH,y+WIDTH,0,0,WIDTH*numWidths,WIDTH*numWidths,null);
		
	}

	public void addTransform(float parseFloat, float parseFloat2,
			float parseFloat3, float parseFloat4, float parseFloat5,
			float parseFloat6) {
		AffineTransform t = new AffineTransform(parseFloat, parseFloat2, parseFloat3, parseFloat4, parseFloat5, parseFloat6);
		System.out.println(t.toString());
		transforms.add(t);
		target = source;
		doStep();
		
	}
	
	public void clearTransforms()
	{
		transforms.clear();
		target = source;
		doStep();
	
	}
	
	private class Maxes
	{
		float maxX = -10000;
		float minX = 10000;
		float maxY = -10000;
		float minY = 10000;
		
		public String toString()
		{
			return "MaxX=" + maxX + " MinX=" + minX + " MaxY=" + maxY + " MinY=" + minY;
		}
	}
	
	public Maxes computeMaxes()
	{
		float[] points = {0,0,0,1,1,0,1,1};
		float[] results = new float[8];
		Maxes maxes = new Maxes();
		for(AffineTransform t : transforms)
		{
			t.transform(points, 0, results, 0, 4);
			for(int x = 0; x < 7; x = x + 2) {
				if(results[x] > maxes.maxX) {
					maxes.maxX = results[x];
				}
				if(results[x] < maxes.minX) {
					maxes.minX = results[x];
				}
			}
			for(int y = 1; y < 8; y = y + 2) {
				if(results[y] > maxes.maxY) {
					maxes.maxY = results[y];
				}
				if(results[y] < maxes.minY) {
					maxes.minY = results[y];
				}
			}
		}
		return maxes;
		
		
	}
	
	public void setZoom(int zoom)
	{
		zoomLevel = zoom;
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		
		if(e.getX() > 507 && e.getY() > 1 && e.getX() < (507 + WIDTH) && e.getY() < (1 + WIDTH))
		{
			System.out.println(e.getX() + " " + e.getY());
			Graphics2D sourceG = target.createGraphics();
			AffineTransform trans = new AffineTransform();
			sourceG.setColor(Color.blue);
			sourceG.translate(WIDTH*BORDER  - zoomLevel*WIDTH, WIDTH*BORDER - zoomLevel*WIDTH);
			sourceG.scale(1 + (2*zoomLevel), 1 + (2*zoomLevel));
			sourceG.fillOval(e.getX() - 507, e.getY() - 1, 10, 10);
			repaint();
			
		}
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		
		
	}




}
