import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class MainFrame extends JFrame implements ActionListener, ChangeListener {

	FractalCanvas canvas;
	TextField[] matrixFields;
	JButton stepButton;
	JButton addButton;
	JButton clearButton;
	JSlider zoomSlider;
	
	public MainFrame()
	{
		super("MRCM Example");
		//setSize(300,300);
		
		
		BufferedImage img = null;
		try {
		    img = ImageIO.read(new File("weeninja.png"));
		} catch (IOException e) {
			throw new RuntimeException(e.toString());
		}
		
		canvas = new FractalCanvas(img);
		
		LayoutManager layout = new BorderLayout();
		Container content = getContentPane();
	    content.setBackground(Color.white);
	    content.setLayout(layout); 
	    content.add(canvas, BorderLayout.NORTH);
	    JPanel panel = new JPanel();
	    panel.setLayout(new FlowLayout());
	    content.add(panel, BorderLayout.CENTER);
	    stepButton = new JButton("Step");
	    panel.add(stepButton, BorderLayout.CENTER);
	    stepButton.addActionListener(this);
	    
	    JPanel matrixPanel = new JPanel();
	    matrixPanel.setLayout(new GridLayout(3,2));
	    matrixFields = new TextField[6];
	    for(int i = 0; i < 6; i++)
	    {
	    	TextField t = new TextField();
	    	matrixFields[i] = t;
	    	t.setColumns(5);
	    	matrixPanel.add(t);
	    }
	    panel.add(matrixPanel);
	    addButton = new JButton("Add Transform");
	    addButton.addActionListener(this);
	    panel.add(addButton);
	    
	    clearButton = new JButton("Clear Transform");
	    clearButton.addActionListener(this);
	    panel.add(clearButton);
	    
	    zoomSlider = new JSlider(0,FractalCanvas.BORDER,0);
	    zoomSlider.setMajorTickSpacing(1);
	    zoomSlider.setSnapToTicks(true);
	    zoomSlider.setPaintTicks(true);
	    zoomSlider.setPaintLabels(true);
	    Hashtable<Integer,JLabel> labelTable = new Hashtable<Integer,JLabel>();
	    labelTable.put( new Integer( 0 ), new JLabel("zoomed in") );
	    labelTable.put( new Integer( FractalCanvas.BORDER ), new JLabel("zoomed out") );
	    zoomSlider.setLabelTable( labelTable );
	    zoomSlider.addChangeListener(this);
	    panel.add(zoomSlider);
	    
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    System.out.println(canvas.getPreferredSize());
	    super.pack();
	}
	
	public static void main(String[] args) {

		JFrame frame = new MainFrame();
		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == stepButton) {
			canvas.doStep();
		}
		if(e.getSource() == addButton)
		{
			canvas.addTransform(
					Float.parseFloat(matrixFields[0].getText()),
					Float.parseFloat(matrixFields[1].getText()),
					Float.parseFloat(matrixFields[2].getText()),
					Float.parseFloat(matrixFields[3].getText()),
					Float.parseFloat(matrixFields[4].getText()),
					Float.parseFloat(matrixFields[5].getText()));
			
		}
		if(e.getSource() == clearButton)
		{
			canvas.clearTransforms();
		}
		canvas.repaint();
	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		canvas.setZoom(zoomSlider.getValue());
		canvas.repaint();
		
	}

}
